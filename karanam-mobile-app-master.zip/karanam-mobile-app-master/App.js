import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { PersistGate } from 'redux-persist/integration/react';
import { Provider } from 'react-redux';

import MainStack from './src/navigation/mainStack';
import configureStore from './src/store/storeConfig/store';

export const { store, persistor } = configureStore();

console.disableYellowBox = true;

export const navigationRef = React.createRef();

const App = () => {
  return (
    <NavigationContainer ref={navigationRef}>
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <MainStack/>
        </PersistGate>
      </Provider>
    </NavigationContainer>
  );
};

export default App;