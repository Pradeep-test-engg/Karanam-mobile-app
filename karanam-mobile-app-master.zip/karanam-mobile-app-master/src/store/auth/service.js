import request from '../../utils/fetch';

export const send_register_otp = (data) => request.post(`public/register/sendOtp`,data);

export const send_registerVerify_otp = (data) => request.post(`public/register/verify`,data);

export const loginEmail = (data) => request.post(`public/login`,data);

export const loginSendOtp = (data) => request.post(`public/loginMobile/sendOtp`,data);

export const loginVerifyOtp = (data) => request.post(`public/loginMobile/verify`,data);

export const updateProfile = (user_id,data) => request.put(`private/user/${41}/profile/update`,data);

export default {
    updateProfile,
}
