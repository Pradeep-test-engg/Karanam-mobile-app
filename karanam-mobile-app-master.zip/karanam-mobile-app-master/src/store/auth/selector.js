import { createSelector } from 'reselect'

const basicInfoSelect = state => Object.fromEntries(Object.entries(state.auth.user.basic).filter(([key]) => ['basic', 'address', 'dob', 'firstname', 'lastname', 'gender', 'state', 'city'].includes(key)));
const basicInfo = createSelector(basicInfoSelect, (value) => value );

const IdDetailsSelect = state => Object.fromEntries(Object.entries(state.auth.user.id_details).filter(([key]) => ['aadhar', 'has_work_permit', 'pan', 'passport', 'startDate', 'endDate', 'wpContry', 'wpNumber' ].includes(key)));
const IdDetails = createSelector(IdDetailsSelect, (value) => value );

const educationSelect = state => Object.fromEntries(Object.entries(state.auth.user.education).filter(([key]) => ['college_name', 'college_percentage', 'degree_college', 'degree_completed', 'degree_percentage', 'degree_type', 'school_name', 'search_job', 'sslc_percentage' ].includes(key)));
const education = createSelector(educationSelect, (value) => value );

const experienceSelect = state => Object.fromEntries(Object.entries(state.auth.user.experience).filter(([key]) => ['crntOrg', 'designation', 'i_higher_edu', 'choose_high_degree', 'i_domain_change', 'd_change_comments', 'i_org_change', 'o_change_comments', 'skill_set' ].includes(key)));
const experience = createSelector(experienceSelect, (value) => value );

const credentialSelect = state => Object.fromEntries(Object.entries(state.auth.user.credential).filter(([key]) => ['profession', 'email', 'phone_no'].includes(key)));
const credential = createSelector(credentialSelect, (value) => value );

const useIdSelect = state => state.auth.user.basic;
const useId = createSelector(useIdSelect, (value) => value );

export default {
    basicInfo,
    IdDetails,
    education,
    experience,
    credential,
    useId,
}
