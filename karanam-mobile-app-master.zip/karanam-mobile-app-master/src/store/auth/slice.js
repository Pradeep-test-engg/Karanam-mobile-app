import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    user:{
        user:{id:77},
        token:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjo0MSwiaWF0IjoxNjA5MjM1MDkyfQ.knO3NglqogaEJufVJfuNyddzVP82uM4e68q5O_Ydhtc",
    },
    is_user:true,
};

const authSlice = createSlice({
    name:"auth",
    initialState:initialState,
    reducers:{
        login: (state, action) => {
            state.user = action.payload;
            state.is_user = true;
        },
        logout : (state,action) => {
            state.user = {};
            state.is_user = false;
        },
        updateProfile : ( state, action ) =>{
            state.user[action.payload.type] = action.payload.data;
        },
    },
});

export default authSlice;
