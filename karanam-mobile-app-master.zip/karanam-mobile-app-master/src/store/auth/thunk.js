import authSlice from './slice';
import authService ,{ loginEmail, loginSendOtp, loginVerifyOtp } from './service';
import commonSelector from '../common/selector';

export const sendOtpThunk = (data)=>{
    return function thunkFunction(dispatch) {
        dispatch(authSlice.actions.login(data));
    }
  }

export const loginEmailThunk = (data)=>{
    return async function thunkFunction(dispatch) {
        let res = await loginEmail(data);
        dispatch(authSlice.actions.login(res));
    }
  }

export const loginSendOtpThunk = (data)=>{
    return async function thunkFunction(dispatch) {
        let res = await loginSendOtp(data);
    }
  }

export const loginVerifyOtpThunk = (data)=>{
    return async function thunkFunction(dispatch) {
        let res = await loginVerifyOtp(data);
        dispatch(authSlice.actions.login(res));
    }
  }

const updateProfile = ({ data, handler, type }) => async(dispatch,getState) => {
  try {
        handler( (prevState) => ({...prevState,loading:true}));
        const result = await authService.updateProfile(commonSelector.getUserId(getState),data);
        dispatch(authSlice.actions.updateProfile({data:result,type:type}));
        handler( (prevState) => ({...prevState,loading:false}));
  } catch (error) {
    handler( (prevState) => ({...prevState,loading:false,error:error}));
  }
}

export default {
  updateProfile,
}