import course_slice from './slice';
import  * as course from './service';
import courseService from './service';

export const get_all_my_course_thunk = (user_id,data)=>{
    return async function thunkFunction(dispatch) {    
        dispatch(course_slice.actions.course_loading(result));
        const result = await course.allMyCourse(user_id,data);
        dispatch(course_slice.actions.course_success(result));
    }
  }

const getMyLatestCourse = ({ data, handler }) => async(dispatch,getState) => {
    try {
        
        handler( (prevState) => ({...prevState,loading:true}));

        const result = await courseService.allMyCourse(data);

        dispatch(course_slice.actions.course_success(result));

        // dispatch(authSlice.actions.updateProfile({data:result,type:type}));

        handler( (prevState) => ({...prevState,loading:false}));
    } catch (error) {
      handler( (prevState) => ({...prevState,loading:false,error:error}));
    }
  }
  
export const allSubscribedCourse = (data)=>{
  return async function thunkFunction(dispatch,getState) {    
    console.log("aaaaaaaaaaaa");    
      dispatch(course_slice.actions.course_loading());
      const result = await course.allMyCourse(getState().auth.user.user.id,data);
      dispatch(course_slice.actions.course_success({payload:result}));
  }
}

export default {
    getMyLatestCourse,
    allSubscribedCourse,
}
