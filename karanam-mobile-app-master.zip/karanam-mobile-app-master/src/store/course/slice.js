import { createSlice } from '@reduxjs/toolkit';

const initial_state = {
   my_course_list:{
       data:[],
       loading:false,
       page_loading:false,
   },
};

const course_slice = createSlice({

    name:"course",
    initialState:initial_state,
    reducers:{

        course_loading: (state) => {
            state.my_course_list.loading = true;
        },
        course_success: (state,action) => {
            state.my_course_list.loading = false;
            state.my_course_list.data = action.payload;
        },

    }
});

export default course_slice;
