import { createSelector } from 'reselect';

const myCourseSelect = (state) => state.course.my_course_list;
const myCourse = createSelector(myCourseSelect, (value) => value );

export default {
    myCourse,
}
