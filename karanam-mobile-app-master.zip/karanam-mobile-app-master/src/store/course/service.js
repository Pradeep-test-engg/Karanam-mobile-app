import request from '../../utils/fetch';

export const allMyCourse = ({user_id = 77,page,limit}) => request.get(`private/controller/course/user/${user_id}/subscribed/courses?page=${page}&limit=${limit}`);

export const get_lesson_details_service = (user_id,{course_id,lesson_id}) => request.get(`private/user/${user_id}/course/${course_id}/lesson-details/${lesson_id}`);

export const update_course_progress = (user_id,course_id,data) => request.put(`public/user/${user_id}/course-progress/${course_id}`,data);

export const get_course_progress = (user_id,course_id) => request.get(`public/user/${user_id}/course-progress/${course_id}`);

export const get_mycourse_details_service = (user_id,course_id) => request.get(`private/controller/course/${course_id}/user/${user_id}/sections`);



export default {
    allMyCourse,
}
