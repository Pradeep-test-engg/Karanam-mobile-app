import request from '../../utils/fetch';

export const getAllCategorysSrvc = () => request.get(`public/controller/category/all`);

export const getAllCourseBySubCatSrv = ({ subCatId, page, limit }) => request.get(`public/course/subCat/${subCatId}/all?page=${page}&limit=${limit}`);

export const getCourseDetailByIdSrv = ({courseId}) => request.get(`public/course/${courseId}/details`);

// COURSE BUY 
export const course_buy_service = (user_id,data) => request.post(`public/user/${user_id}/course/buy`,data);

// COURSE SEARCH API
const searchCourse = ({query,page,limit}) => request.get(`public/controller/course/all?search=${query}&page=${page}&limit=${limit}`);

export default {
    searchCourse,
}