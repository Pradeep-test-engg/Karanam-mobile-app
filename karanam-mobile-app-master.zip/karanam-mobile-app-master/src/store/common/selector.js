const getUserId = (getState) =>{
    return getState && getState().auth.user.basic.id;
  }

export default {
    getUserId,
}