import cartSlice from './cart';
import { add_to_cart_service, course_buy_service, add_to_wishlist_service, get_all_cart_service, get_all_wishlist_service, remove_cartwishlist_service } from './cartService';

export const get_all_cart_thunk = (user_id)=>{
    return async function thunkFunction(dispatch) {
        const result = await get_all_cart_service(user_id);
        dispatch(cartSlice.actions.cartSuccess(result));
    }
  }

export const add_to_cart_thunk = (user_id,data,from_wishlist)=>{
    return async function thunkFunction(dispatch) {
        const result = await add_to_cart_service(user_id,data);
        await dispatch(get_all_cart_thunk(user_id));
        if(from_wishlist){
          await dispatch(get_all_wishlist_thunk(user_id));
        }
    }
  }

export const add_to_wishlist_thunk = (user_id,data,from_cart)=>{
  return async function thunkFunction(dispatch) {
      const result = await add_to_wishlist_service(user_id,data);
      await dispatch(get_all_wishlist_thunk(user_id));
      if(from_cart){
        await dispatch(get_all_cart_thunk(user_id));
      }
  }
}

export const get_all_wishlist_thunk = (user_id)=>{
    return async function thunkFunction(dispatch) {
        const result = await get_all_wishlist_service(user_id);
        dispatch(cartSlice.actions.wishlistSuccess(result));
    }
  }

// COURSE PURCHARE THUNK
export const course_purchase_thunk = (user_id,data)=>{
    return async function thunkFunction(dispatch) {
        const result = await course_buy_service(user_id,data);
        console.log(result);
        dispatch(get_all_cart_thunk(user_id));
    }
  }

export const remove_cartwishlist_thunk = (user_id,data,wishtlist) =>{
  return async function thunkFunction(dispatch) {
    const result = await remove_cartwishlist_service(user_id,data);
    if(wishtlist){
      await dispatch(get_all_wishlist_thunk(user_id));
    }
    else{
      await dispatch(get_all_cart_thunk(user_id)); 
    }
  }
}