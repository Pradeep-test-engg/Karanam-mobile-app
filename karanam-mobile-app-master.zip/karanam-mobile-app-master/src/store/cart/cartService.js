import request from '../../utils/fetch';

export const get_all_cart_service = (user_id) => request.get(`public/user/${user_id}/cart/all`);

export const get_all_wishlist_service = (user_id) => request.get(`public/user/${user_id}/wishlist/all`);

export const add_to_cart_service = (user_id,data) => request.post(`public/user/${user_id}/cart/add`,data);

export const add_to_wishlist_service = (user_id,data) => request.post(`public/user/${user_id}/wishlist/add`,data);

// COURSE BUY
export const course_buy_service = (user_id,data) => request.post(`public/user/${user_id}/course/buy`,data);

// CART AND WISHLIST REMOVE 
export const remove_cartwishlist_service = (user_id,data) => request.delete(`public/user/${user_id}/cartWishlist/remove`,data);