import { createSlice } from '@reduxjs/toolkit';

const initialState = {
   cartItems:{
       data:[],
       loading:false
   },
   wishlistItems:{
    data:[],
    loading:false
    },
};

const cartSlice = createSlice({
    name:"cart",
    initialState:initialState,
    reducers:{

        cartLoading: (state, action) => {
            state.cartItems.loading = true;
        },
        cartSuccess: (state,action) => {
            state.cartItems.loading = false;
            state.cartItems.data = action.payload;
        },
        cartAddSingle: (state,action) => {
            state.cartItems.data.push(action.payload);
        },

        wishlistLoading: (state, action) => {
            state.wishlistItems.loading = true;
        },
        wishlistSuccess: (state,action) => {
            state.wishlistItems.loading = false;
            state.wishlistItems.data = action.payload;
        },
        wishlistAddSingle: (state,action) => {
            state.wishlistItems.data.push(action.payload);
        },
    }
});

export default cartSlice;