import { combineReducers } from 'redux';
import authSlice from '../auth/slice';
import cartSlice from './../cart/cart';
import course_slice from './../course/slice';

const rootReducer = combineReducers({
    auth:authSlice.reducer,
    cart:cartSlice.reducer,
    course:course_slice.reducer
});

export default rootReducer;