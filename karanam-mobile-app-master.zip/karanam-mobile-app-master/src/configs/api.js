const API_ENDPOINT = "http://localhost:5000/api/v1/";

export default API_ENDPOINT;