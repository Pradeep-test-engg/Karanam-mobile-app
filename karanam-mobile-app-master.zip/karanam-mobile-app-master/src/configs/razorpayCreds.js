export const razorCreds = {
    key_id:"rzp_test_hl8HahmBL0knar",
    key_secret:"T6s77DRLW2dEJRstW5BOvxLs"
}