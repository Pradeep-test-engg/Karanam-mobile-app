import React, { useEffect } from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { connect } from 'react-redux';
import messaging from '@react-native-firebase/messaging';

import Login from '../screens/auth/login/login';
import navigator, { profile_stack, main_stack } from './navigator';
import SignUp from '../screens/auth/signUp';
import Home from '../screens/home/home';
import DrawerStack from './drawerStack';
import LoginOtp from '../screens/auth/login/loginOtp';
import LoginOtpVerify from '../screens/auth/login/loginOtpVerify';
import forgotPswd from '../screens/auth/login/forgotPaswd';
import Test from '../screens/test/test';
import CourseDetails from '../screens/course/courseDetails';
import CourseBuy from '../screens/course/coursebuy/coursebuy';
import SearchScreen from '../screens/search';
import Cart from '../screens/cart/cart';
import Wishlist from '../screens/wishlist/wishlist';
import Checkout from '../screens/checkout/checkout';
import CourseList from '../screens/course/courseList/courseList';
import ProfileStack from './profileStack';
import AuthStack from './authStack';
import SubScribedCourseDetails from '../screens/course/subscribed/courseDetails'

const Stack = createStackNavigator();

const MainStack = (props) => {

    const { is_user } = props;

    if(is_user){
        return (
            <Stack.Navigator initialRouteName={navigator.home}>
                <Stack.Screen name={navigator.home} component={DrawerStack} />
                <Stack.Screen name={navigator.test} component={Test} />
                <Stack.Screen name={navigator.CourseDetails} component={CourseDetails} />
                <Stack.Screen name={navigator.CourseBuy} component={CourseBuy} />
                <Stack.Screen name={main_stack.search_screen} component={SearchScreen} />

                <Stack.Screen name={navigator.Cart} component={Cart} />
                <Stack.Screen name={navigator.Wishlist} component={Wishlist} />
                <Stack.Screen name={navigator.Checkout} component={Checkout} />
                <Stack.Screen name={navigator.CourseList} component={CourseList} />

                <Stack.Screen name={profile_stack.profile_detail} component={ProfileStack} />

                <Stack.Screen name={main_stack.SubScribedCourseDetails} component={SubScribedCourseDetails} />

            </Stack.Navigator>
        )
    }

    else{
        return (
            <AuthStack />
        )
    }
}

const mapStateToProps = (state) =>{
    return{
        is_user:state.auth.is_user,
    }
}

export default connect(mapStateToProps)(MainStack);
