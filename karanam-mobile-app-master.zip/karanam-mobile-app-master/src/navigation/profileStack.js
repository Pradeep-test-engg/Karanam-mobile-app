import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { profile_stack } from './navigator';
import ProfileDetail from '../screens/profile/myprofile/profiledetails';
import BasicInfo from './../screens/profile/myprofile/profiledetails/basicinfo';
import Education from './../screens/profile/myprofile/profiledetails/education';
import Experience from './../screens/profile/myprofile/profiledetails/experience';
import IdDetails from './../screens/profile/myprofile/profiledetails/identification';
import Credential from './../screens/profile/myprofile/profiledetails/credential/index';
import Password from '../screens/profile/myprofile/profiledetails/password';

const Stack = createStackNavigator();

const ProfileStack = () => {

        return (

            <Stack.Navigator initialRouteName={profile_stack.profile_detail} headerMode="none">

                <Stack.Screen name={profile_stack.profile_detail} component={ProfileDetail} />
                <Stack.Screen name={profile_stack.basic_info} component={BasicInfo} />
                <Stack.Screen name={profile_stack.credential} component={Credential} />
                <Stack.Screen name={profile_stack.id_details} component={IdDetails} />
                <Stack.Screen name={profile_stack.education} component={Education} />
                <Stack.Screen name={profile_stack.experience} component={Experience} />
                <Stack.Screen name={profile_stack.password} component={Password} />

            </Stack.Navigator>
        )
    }

export default ProfileStack