import React, { useEffect } from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import Home from '../screens/home/home';
import navigator from './navigator';
import { color, font, size, Icon } from '../styles/index.js';
import MyCourse from '../screens/course/subscribed/allCourses';
import MyProfile from '../screens/profile/myprofile/myprofile';
import MyTest from '../screens/test/mytest/mytest';

const Tab = createBottomTabNavigator();

const TabStack = (props) => {
 
    return (

        <Tab.Navigator initialRouteName={navigator.home}
            tabBarOptions={{
                labelStyle:{
                    fontFamily:font.bold,
                    fontSize: size.small,
                },
                keyboardHidesTabBar:true,
                }}
            >
            <Tab.Screen name={navigator.home} component={Home} 
                options={{
                    tabBarLabel: 'Home',
                    tabBarIcon: () => (
                    <Icon name="home" type="MaterialIcons" style={{color:color.black,fontSize:size.xbig}} />
                    ),
                }}
            />
             <Tab.Screen name={navigator.MyCourse} component={MyCourse} 
                options={{
                    tabBarLabel: 'My Course',
                    tabBarIcon: () => (
                    <Icon name="results" type="Foundation" style={{color:color.black,fontSize:size.xbig}} />
                    ),
                }}
            />
            <Tab.Screen name={navigator.MyTest} component={MyTest} 
                options={{
                    tabBarLabel: 'My Tests',
                    tabBarIcon: () => (
                    <Icon name="indeterminate-check-box" type="MaterialIcons" style={{color:color.black,fontSize:size.xbig}} />
                    ),
                }}
            />

             <Tab.Screen name={navigator.MyProfile} component={MyProfile} 
                options={{
                    tabBarLabel: 'Profile',
                    tabBarIcon: () => (
                    <Icon name="user-alt" type="FontAwesome5" style={{color:color.black,fontSize:size.xbig}} />
                    ),
                }}
            />

        </Tab.Navigator>
    )
}

export default TabStack;