const navigator = {
    home:"home",
    login:"login",
    signUp:"signUp",
    LoginOtp:"LoginOtp",
    LoginOtpVerify:"LoginOtpVerify",
    forgotPswd:"forgotPswd",
    test:"test",
    CourseDetails:"CourseDetails",

    MyCourse:"MyCourse",
    MyTest:"MyTest",
    MyProfile:"MyProfile",

    CourseBuy:"CourseBuy",
    Search:"Search",

    Cart:"Cart",
    Wishlist:"Wishlist",
    Checkout:"Checkout",

    CourseList:"CourseList",

}

export default navigator;

export const profile_stack = {
    profile_detail:"ProfileDetail",
    basic_info:"BasicInfo",
    credential:"Credential",
    education:"Education",
    experience:"Experience",
    id_details:"IdDetails",
    password:"Password",
}

export const main_stack = {
    search_screen:"SearchScreen",

    SubScribedCourseDetails:"SubScribedCourseDetails",
}
