import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';

import navigator from './navigator';
import TabStack from './tabStack';
import HomeDrawer from '../screens/home/drawer/drawer';

const Drawer = createDrawerNavigator();

const DrawerStack = (props) => {
    return(
        <Drawer.Navigator initialRouteName={navigator.home} drawerContent={()=> (<HomeDrawer {...props} />)} 
            drawerStyle={{
                width: 200,
            }}>
            <Drawer.Screen name={navigator.home} component={TabStack} />
        </Drawer.Navigator>
    )
}

export default DrawerStack;