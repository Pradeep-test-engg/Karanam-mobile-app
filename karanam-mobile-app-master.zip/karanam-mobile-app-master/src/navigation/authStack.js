import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';

import Login from '../screens/auth/login/login';
import navigator from './navigator';
import SignUp from '../screens/auth/signUp';
import LoginOtp from '../screens/auth/login/loginOtp';
import LoginOtpVerify from '../screens/auth/login/loginOtpVerify';
import forgotPswd from '../screens/auth/login/forgotPaswd';

const Stack = createStackNavigator();

const AuthStack = () => {

    return (
        <Stack.Navigator initialRouteName={navigator.login}>

            <Stack.Screen name={navigator.login} component={Login}/>

            <Stack.Screen name={navigator.signUp} component={SignUp}/>

            <Stack.Screen name={navigator.LoginOtp} component={LoginOtp}/>

            <Stack.Screen name={navigator.LoginOtpVerify} component={LoginOtpVerify}/>

            <Stack.Screen name={navigator.forgotPswd} component={forgotPswd}/>

        </Stack.Navigator>
    )

}

export default AuthStack;
