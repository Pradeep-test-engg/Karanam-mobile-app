import React, { useState, useEffect } from 'react';
import { SafeAreaView, ScrollView, View, TouchableOpacity, Image, ActivityIndicator } from 'react-native';
import StatusBar from '../../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../../styles/index.js';
import Header from '../../../components/header/header';
import TextComp from '../../../components/text/text';
import { FlatList } from 'react-native-gesture-handler';
import { getAllCourseBySubCatSrv } from '../../../store/common/services';
import navigator from '../../../navigation/navigator';

const CourseList = (props) => {

    const [ data, setData ] = useState({
        payload:null,
        loading:false,
        error:null
    });

    useEffect(()=>{

        getInitialData();

    },[]);

    const getInitialData = async() =>{
        try {

            setData({
                ...data,
                loading:true
            })

            let result = await getAllCourseBySubCatSrv({subCatId:props.route.params.id,page:1,limit:6})

            setData({
                ...data,
                loading:false,
                payload:result
            })

        } catch (error) {
            setData({
                ...data,
                loading:false
            })

        }
    }

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Courses"}
                    onLeftPress={()=>{props.navigation.goBack()}}
                />

                <View style={{flex:1}}>

                    <View style={{marginHorizontal:16,marginTop:16}}>
                        <TextComp value={`${props.route.params.details.name} courses`} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.xbig}}/>
                    </View>

                    {
                        data.loading ?
                            <View style={{flex:1,alignItems:"center",justifyContent:"center"}}>
                                <ActivityIndicator animating={data.loading} color={color.xblue} size={size.xxxxbig} />
                            </View>
                        :
                        <View style={{marginHorizontal:10,marginTop:16}}>

                            <FlatList
                                data={data.payload ? data.payload.rows : []}
                                renderItem={({item,key})=> <CourseItem item={item} key={key} navigation={props.navigation} />}
                                ListEmptyComponent={
                                    <View style={{flex:1,alignItems:"center",justifyContent:"center",marginTop:150}}>
                                        <TextComp value={"No courses found"} style={{fontSize:size.xxbig}}/>
                                    </View>
                                }
                            />

                        </View>
                    }

                </View>
            </ScrollView>

        </SafeAreaView>
    );

};

export default CourseList;

const CourseItem = ({item,key,navigation}) =>{

    return(
        <TouchableOpacity key={key} style={{backgroundColor:color.xxgray,marginBottom:12,padding:10,borderRadius:6}}
            onPress={()=>{navigation.navigate(navigator.CourseBuy,{id:item.id})}}>
            <View style={{flexDirection:"row",alignItems:"center"}}>

                <View style={{height:55,width:55}}>
                    <Image source={{uri:item.thumbnail}} style={{height:"100%",width:"100%",borderRadius:6}} />
                </View>

                <View style={{flex:1}}>
                    <View>
                        <TextComp value={item.title} style={{textAlign:"center",fontSize:size.small,fontFamily:font.bold}}/>
                        <TextComp value={item.short_description} style={{color:color.xgray,fontSize:size.xsmall,marginTop:4}}/>
                    </View>
                </View>

            </View>
        </TouchableOpacity>
    )
}