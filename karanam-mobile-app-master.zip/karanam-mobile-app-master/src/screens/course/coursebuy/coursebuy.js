import React, { useState, useEffect } from 'react';
import { SafeAreaView, ScrollView, View, TouchableOpacity, Image, ActivityIndicator } from 'react-native';
import StatusBar from '../../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../../styles/index.js';
import Header from '../../../components/header/header';
import TextComp from '../../../components/text/text';
import Button from '../../../components/button/button';
import { FlatList } from 'react-native-gesture-handler';
import { razorPay } from '../../../utils/razorPay';
import navigator from '../../../navigation/navigator';
import { getCourseDetailByIdSrv } from '../../../store/common/services';
import { add_to_cart_thunk } from '../../../store/cart/cartThunk';
import { connect } from 'react-redux';
import { add_to_wishlist_thunk } from './../../../store/cart/cartThunk';

const CourseBuy = (props) => {

    const [ show, setShow ] = useState(false);

    const [ data, setData ] = useState({
        payload:null,
        loading:false,
        error:null
    });

    useEffect(()=>{

        getInitialData();

    },[]);

    const getInitialData = async() =>{
        try {

            setData({
                ...data,
                loading:true
            })

            let result = await getCourseDetailByIdSrv({courseId:props.route.params.id})

            setData({
                ...data,
                loading:false,
                payload:result
            })

        } catch (error) {
            setData({
                ...data,
                loading:false
            })

        }
    }

    const handle_add_to_cart = () =>{
        
        props.add_to_cart(props.user_id,{"course_id":data.payload.id});
    }

    const handle_add_to_wishlist = () =>{
        
        props.add_to_wishlist(props.user_id,{"course_id":data.payload.id});
    }

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Course details"}
                    onLeftPress={()=>{props.navigation.goBack()}}
                    rightIcon={{
                        type:"MaterialIcons",
                        name:"shopping-cart",
                        size:size.xxxbig
                    }}
                />

                { data.loading ?
                    <View style={{flex:1,alignItems:"center",justifyContent:"center"}}>
                        <ActivityIndicator animating={data.loading} color={color.xblue} size={size.xxxxbig} />
                    </View>
                :
                <View style={{flex:1}}>

                        <View style={{marginHorizontal:16,marginTop:16}}>
                            <TextComp value={data.payload ? data.payload.title : null} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.xxbig}}/>
                            <TextComp value={data.payload ? data.payload.short_description : null} style={{textAlign:"left",fontFamily:font.bold,color:color.xgray,fontSize:size.small,marginTop:10}}/>
                        
                            <View style={{flexDirection:"row",justifyContent:"flex-start",alignItems:"center",marginTop:10}}>
                                <Icon name="star" type="MaterialIcons" style={{color:color.orange,fontSize:size.medium}} />
                                <Icon name="star" type="MaterialIcons" style={{color:color.orange,fontSize:size.medium}} />
                                <Icon name="star" type="MaterialIcons" style={{color:color.orange,fontSize:size.medium}} />
                                <Icon name="star" type="MaterialIcons" style={{color:color.orange,fontSize:size.medium}} />
                                <Icon name="star-half" type="MaterialIcons" style={{color:color.orange,fontSize:size.medium}} />
                                <TextComp value={"4.5 (87)"} style={{marginLeft:5,textAlign:"left",fontFamily:font.bold,color:color.black,fontSize:size.small}}/>
                            </View>
                        </View>

                        <View style={{height:200,marginHorizontal:30,marginVertical:20}}>
                            <Image source={{uri:data.payload ? data.payload.thumbnail : null}} style={{height:"100%",width:"100%"}} />
                        </View>

                        {
                            !props.route.params.isPurch &&
                            <>
                                <View style={{marginHorizontal:16}}>
                                    <TextComp value={`₹ ${data.payload ? data.payload.price : null} `} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.xxbig}}/>
                                </View>

                                <View style={{marginHorizontal:10,alignItems:"center",justifyContent:"center",marginVertical:20}}>
                                    <Button value={"Buy now"} width="80%" onPress={()=>{razorPay(455*100)}}/>
                                </View>

                                <View>

                                    <View style={{flex:1,flexDirection:"row",alignItems:"center",justifyContent:"space-around",zIndex:-10}}>
                                        <Button value={"Add to cart"} onPress={handle_add_to_cart} buttonStyle={{backgroundColor:color.xxgray}} textStyle={{color:color.xgray}} />
                                        <Button value={"Add to wishlist"} onPress={handle_add_to_wishlist} buttonStyle={{backgroundColor:color.xxgray}} textStyle={{color:color.xgray}} />
                                    </View>

                                </View>
                            </>
                        }

                        <View>
                        <View style={{marginHorizontal:16,marginTop:20}}>
                            <TextComp value={"Course Content"} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.xbig}}/>
                            <TextComp value={"21 sections • 121 lectures • 3h 7m total length"} style={{textAlign:"left",fontFamily:font.bold,color:color.xgray,fontSize:size.small,marginTop:10}}/>
                        </View>
                    </View>

                    <View style={{marginTop:14}}>

                        <FlatList
                            data={data.payload ? data.payload.section : []}
                            renderItem={({item})=><Sections item={item} />}
                        />

                    </View>

                </View>
            }
            </ScrollView>

        </SafeAreaView>
    );

};

const mapStateToProps = (state) =>{
    return{
        user_id:state.auth.user.user.id,
        cart_length:state.cart.cartItems.data.length
    };
}

const mapDispatchToProps = (dispatch) =>{

    return{
        add_to_cart:(user_id,data)=>{dispatch(add_to_cart_thunk(user_id,data))},
        add_to_wishlist:(user_id,data)=>{dispatch(add_to_wishlist_thunk(user_id,data))},
    };

}
  
export default connect(mapStateToProps,mapDispatchToProps)(CourseBuy);

const Sections = ({item}) =>{
    
    return( 
            <>
                <TouchableOpacity style={{backgroundColor:color.xxgray,marginHorizontal:14,marginVertical:6,borderRadius:6,flexDirection:"row",alignItems:"center",justifyContent:"space-between"}}>
                    <TextComp value={`${item.title}`} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.big,paddingVertical:12,marginLeft:10}}/>
                    {
                        false 
                        ? <Icon name="chevron-right" type="MaterialIcons" style={{fontSize:size.xxxbig,right:10}} /> 
                        : <Icon name="keyboard-arrow-down" type="MaterialIcons" style={{fontSize:size.xxxbig,right:10}} />
                    } 
                </TouchableOpacity>
                <FlatList
                    data={item.Lessons}
                    renderItem={({item})=><Lessons item={item} />}
                />
            </>
        )
}

const Lessons = ({item}) =>{
    
    return( 
            <View style={{marginHorizontal:14,borderRadius:6,marginTop:6}}>
                <View style={{backgroundColor:"lightblue",flex:1,marginLeft:14,paddingVertical:8,borderRadius:6,flexDirection:"row",alignItems:"center",justifyContent:"space-around"}}>
                    <View style={{borderRadius:6}}>
                        <Icon name="playcircleo" type="AntDesign" style={{fontSize:size.xbig,right:10}} />
                    </View>
                    <View style={{borderRadius:6}}>
                        <TextComp value={item.title} style={{fontSize:size.xxsmall}}/>
                    </View>
                    <View style={{borderRadius:6}}>
                        <TextComp value={`${item.duration} mins`} style={{textAlign:"left",fontSize:size.xxsmall}}/>
                    </View>
                </View>
            </View>
        )
    }