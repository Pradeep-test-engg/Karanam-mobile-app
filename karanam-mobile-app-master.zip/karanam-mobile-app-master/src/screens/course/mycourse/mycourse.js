import React, { useState, useEffect } from 'react';
import { SafeAreaView, ScrollView, View, TouchableOpacity, Image } from 'react-native';
import StatusBar from '../../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../../styles/index.js';
import Header from '../../../components/header/header';
import TextComp from '../../../components/text/text';
import { FlatList } from 'react-native-gesture-handler';
import { connect } from 'react-redux';
import { get_all_my_course_thunk } from '../../../store/course/thunk';
import navigator from './../../../navigation/navigator';

const MyCourse = (props) => {

    const { 
            user_id,
            my_course_list:{data,loading},
            get_all_my_course,
            } = props;

    useEffect(()=>{

        const data = {
            page:1,
            limit:10
        }
        get_all_my_course(user_id,data)
    },[]);

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"My courses"}
                    onLeftPress={()=>{props.navigation.goBack()}}
                />

                <View style={{flex:1}}>

                    <View style={{marginHorizontal:16,marginTop:16}}>
                        <TextComp value={"All Courses"} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.xxbig}}/>
                    </View>

                    <View style={{marginHorizontal:10,marginTop:16}}>

                        <FlatList
                            data={data.rows}
                            renderItem={(item)=>(<CourseItem {...item} {...props} />)}
                        />

                    </View>

                </View>
            </ScrollView>

        </SafeAreaView>
    );

};

const mapStateToProps = (state) =>{
    return{
        user_id:state.auth.user.user.id,
        my_course_list:state.course.my_course_list
    };
}

const mapDispatchToProps = (dispatch) =>{

    return{
        get_all_my_course:(user_id,data)=>{dispatch(get_all_my_course_thunk(user_id,data))},
    };

}
  
export default connect(mapStateToProps,mapDispatchToProps)(MyCourse);

const CourseItem = ({item,index,navigation}) =>{

    const { Course:{ id, thumbnail, title, short_description }  } = item;

    return(
        <TouchableOpacity onPress={()=>{navigation.navigate(navigator.CourseDetails,{id:id})}} key={index} style={{backgroundColor:color.xxgray,marginBottom:12,padding:10,borderRadius:6}}>
            <View style={{flexDirection:"row",alignItems:"center"}}>

                <View style={{height:55,width:55}}>
                    <Image source={{uri:thumbnail}} style={{height:"100%",width:"100%",borderRadius:6}} />
                </View>

                <View style={{flex:1}}>
                    <View>
                        <TextComp value={title} style={{textAlign:"center",fontSize:size.small,fontFamily:font.bold}}/>
                        <TextComp value={short_description} style={{color:color.xgray,fontSize:size.xsmall,marginTop:4}}/>
                    </View>

                    {/* <View style={{marginLeft:20,marginTop:10}}>
                        <View style={{borderColor:color.xblue,borderWidth:1,marginRight:item.complete}}>
                        </View>
                    </View> */}
                    
                    {/* <View>
                            <TextComp value={`${"item.complete"}% Complete`} style={{color:color.xgray,fontSize:size.xsmall,marginTop:4}}/>
                        </View> 
                    */}

                </View>

            </View>
        </TouchableOpacity>
    )
}