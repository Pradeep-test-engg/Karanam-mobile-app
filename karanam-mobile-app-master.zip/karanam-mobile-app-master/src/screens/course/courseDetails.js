import React, { useState, useEffect } from 'react';
import { SafeAreaView, ScrollView, View, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { color, font, size, Icon } from '../../styles/index.js';
import TextComp from '../../components/text/text';
import { FlatList } from 'react-native-gesture-handler';
import { connect } from 'react-redux';
import VideoPlay from './../../components/videoplayer/videoplayer';
import { get_mycourse_details_service, update_course_progress, get_course_progress } from '../../store/course/service';

const CourseDetails = (props) => {

    const {
        user_id,
        route:{params}
      } = props;

    const [ data, setData ] = useState({
        payload:null,
        loading:false,
        error:null
    });

    const [ currentLesson, setCurrentLesson ] = useState(null);

    const [ progress, setProgress ] = useState({});

    useEffect(()=>{

        getInitialData();
        getInitialData2();

    },[]);

    const getInitialData = async() =>{
        try {
            setData({
                ...data,
                loading:true
            })
            let result = await get_mycourse_details_service(user_id,params.id);
            setData({
                ...data,
                loading:false,
                payload:result
            });
            setCurrentLesson(result.section[0].Lessons[0])
        } catch (error) {
            setData({
                ...data,
                loading:false
            });
        }
    }

    const getInitialData2 = async() =>{
      try {
          let result = await get_course_progress(user_id,params.id);
          setProgress(result);
      } catch (error) {
      }
  }

    const update_progress = (function() {
      let executed = false;
      return function() {
          if (!executed) {
              executed = true;
              let progre = progress.lesson_id ? JSON.parse(progress.lesson_id) : [];
              if(!progre.find(id => (id == currentLesson.id))){
                handleProgressUpdate(currentLesson);
              }
          }
      };
    })();

    const handleProgressUpdate = async(lesson) =>{
        const result = await update_course_progress(props.user_id,props.route.params.id,{lesson_id:lesson.id});
        setProgress(result);
    }

    if(data.loading){
      return (
        <View style={{flex:1,alignItems:"center",justifyContent:"center"}}>
          <ActivityIndicator animating={true} color={color.xblue} size={size.xxxbig} />
        </View>)
    }


    return(
      <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    
        
        <VideoPlay fullscreen={true} data={currentLesson} handleProgressUpdate={update_progress} {...props}>

            <View style={{flex:1,marginVertical:14,marginHorizontal:16}}>

              <FlatList
                  showsVerticalScrollIndicator={false}
                  data={data.payload ? data.payload.section : []}
                  renderItem={({item,index})=><Sections item={item} key={index} progress={progress} currentLesson={currentLesson} setCurrentLesson={setCurrentLesson} />}
                  ListHeaderComponent={
                    <View style={{paddingVertical:6}}>
                        <TextComp value={data.payload ? data.payload.title : null} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.xxbig}}/>
                        <TextComp value={data.payload ? data.payload.short_description : null} style={{textAlign:"left",fontFamily:font.bold,color:color.xgray,fontSize:size.small,marginTop:10}}/>
                    </View>
                  }
              />

            </View>

        </VideoPlay>
      
      </SafeAreaView>
    )

};

const mapStateToProps = (state) =>{
    return{
        user_id:state.auth.user.user.id,
        cart_length:state.cart.cartItems.data.length
    };
}

const mapDispatchToProps = (dispatch) =>{
    return{};
}

export default connect(mapStateToProps,mapDispatchToProps)(CourseDetails);

const Sections = ({item, ...props}) =>{

    const [ show, setShow ] = useState(true);
    
    return( 
            <View style={{backgroundColor:"white"}}>
                <TouchableOpacity onPress={()=>{setShow(!show)}} style={{backgroundColor:color.xxgray,marginVertical:6,borderRadius:6,flexDirection:"row",alignItems:"center",justifyContent:"space-between"}}>
                  <TextComp value={`${item.title}`} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.big,paddingVertical:12,marginLeft:10}}/>
                    {
                      show
                      ? <Icon name="chevron-right" type="MaterialIcons" style={{fontSize:size.xxxbig,right:10}} /> 
                      : <Icon name="keyboard-arrow-down" type="MaterialIcons" style={{fontSize:size.xxxbig,right:10}} />
                    }
                </TouchableOpacity>
                { show &&
                  <FlatList
                      data={item.Lessons}
                      renderItem={({item, index})=><Lessons key={index} item={item} {...props} />}
                  />
                }
            </View>
        )
}

const Lessons = ({item, currentLesson, setCurrentLesson, progress}) =>{
  
    let progre = progress.lesson_id ? JSON.parse(progress.lesson_id) : [];

    return( 
          <TouchableOpacity onPress={()=>{setCurrentLesson(item)}} style={{borderRadius:6,marginVertical:8,overflow:"hidden",marginLeft:12}}>
              <View style={{backgroundColor:currentLesson && currentLesson.id == item.id ? color.xgray : "lightblue" ,flex:1,paddingVertical:8,flexDirection:"row",alignItems:"center",justifyContent:"space-around"}}>
                  <View style={{flex:0.2,alignItems:"center"}}>
                    <Icon name="play-circle" type="MaterialCommunityIcons" color={color.xblue} style={{fontSize:size.xbig,right:0}} />
                  </View>
                  <View style={{flex:1}}>
                      <TextComp value={item.title} style={{textAlign:"left",fontSize:size.big,color:color.black}} />
                      <TextComp value={`${item.duration} mins`} style={{textAlign:"left",fontSize:size.xxsmall}}/>
                  </View>
                  {
                    progre.find(id => (id == item.id)) != undefined &&
                      <View style={{flex:0.2,alignItems:"center"}}>
                          <Icon name="checkbox-marked-circle" type="MaterialCommunityIcons" color={color.orange} style={{fontSize:size.xbig,right:0}} />
                      </View>
                  }
              </View>
          </TouchableOpacity>
        )
    }