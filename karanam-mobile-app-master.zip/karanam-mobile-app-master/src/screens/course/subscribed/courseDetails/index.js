import React, { useState, useEffect } from 'react';
import { View, Text } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import thunk from '../../../../store/course/thunk';
import courseSelector from '../../../../store/course/selector';
import CourseDetails from './courseDetails';
import { get_mycourse_details_service } from '../../../../store/course/service';

export default ({ route }) =>{

    const [ data, setData ] = useState({
        payload:{},
        loading:false,
        error:null
    });

    const [ currentLesson, setCurrentLesson ] = useState(null);

    useEffect(()=>{

        getInitialData();

    },[]);

    const getInitialData = async() =>{
        try {
            setData({
                ...data,
                loading:true
            })
            let result = await get_mycourse_details_service(77,route.params.id);
            setData({
                ...data,
                loading:false,
                payload:result
            });
            // setCurrentLesson(result.section[0].Lessons[0])
        } catch (error) {
            setData({
                ...data,
                loading:false
            });
        }
    }

    return(
        <CourseDetails route={route} data={data} />
    );
}
