import React from 'react';
import { SafeAreaView, ScrollView, View, TouchableOpacity, Image, FlatList } from 'react-native';
import { color, font, size } from '../../../../styles/index.js';
import TextComp from '../../../../components/text/text';
import navigation from '../../../../utils/navigate';
import { main_stack } from './../../../../navigation/navigator';

export default ({ data }) => {

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <View style={{flex:1}}>

                    <View style={{marginHorizontal:16,marginTop:16}}>
                        <TextComp value={"My Courses"} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.xxbig}}/>
                    </View>

                    <View style={{marginHorizontal:10,marginTop:16}}>

                        <FlatList
                            data={data ? data.data : []}
                            renderItem={(item)=>(<CourseItem {...item} />)}
                        />

                    </View>

                </View>
            </ScrollView>

        </SafeAreaView>
    );

};


const CourseItem = ({ item : { id, title, short_description, thumbnail, course_watched_percentage   } }) =>{

    return(
        <TouchableOpacity  style={{backgroundColor:color.xxgray,marginBottom:12,padding:10,borderRadius:6}}
            onPress={()=>{navigation({ path:main_stack.SubScribedCourseDetails, params:{id}})}}>
            <View style={{flexDirection:"row",alignItems:"center"}}>

                <View style={{height:55,width:55}}>
                    <Image source={{uri:thumbnail}} style={{height:"100%",width:"100%",borderRadius:6}} />
                </View>

                <View style={{flex:1,marginHorizontal:10}}>
                    <View>
                        <TextComp value={title} style={{textAlign:"center",fontSize:size.small,fontFamily:font.bold}}/>
                        <TextComp value={short_description} style={{color:color.xgray,fontSize:size.xsmall,marginTop:4}} numberOfLines={2} />
                    </View>

                    <View style={{marginLeft:20,marginTop:10,width:`${course_watched_percentage}%`}}>
                        <View style={{borderColor:color.xblue,borderWidth:1}}>
                        </View>
                    </View>
                    
                    <View>
                        <TextComp value={`${course_watched_percentage}% Complete`} style={{color:color.xgray,fontSize:size.xsmall,marginTop:4}}/>
                    </View>

                </View>

            </View>
        </TouchableOpacity>
    )
}
