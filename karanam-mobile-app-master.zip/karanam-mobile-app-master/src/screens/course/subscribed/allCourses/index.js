import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import thunk from '../../../../store/course/thunk';
import courseSelector from '../../../../store/course/selector';
import MyCourse from './mycourse';

export default () =>{

    const dispatch = useDispatch();

    const { data:{ payload } } = useSelector(courseSelector.myCourse);

    useEffect(()=>{
        dispatch(thunk.allSubscribedCourse());
    },[]);

    return(
        <MyCourse data={payload} />
    );
}
