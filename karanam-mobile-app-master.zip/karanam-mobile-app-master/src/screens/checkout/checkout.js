import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, TouchableOpacity, Image, ActivityIndicator } from 'react-native';
import StatusBar from '../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../styles/index.js';
import Header from '../../components/header/header';
import TextComp from '../../components/text/text';
import { FlatList } from 'react-native-gesture-handler';
import Button from '../../components/button/button';
import { razorPay } from '../../utils/razorPay';
import { connect } from 'react-redux';
import { course_purchase_thunk } from '../../store/cart/cartThunk';
import navigator from './../../navigation/navigator';

const Checkout = (props) => {

    const { user_id,
            cartItems,
            course_purchase,
            } = props;

    const total = calcTotal(cartItems.data);

    const [ status, setStatus ] = useState({
        loading:false,
        isPaid:false,
    })

    const paymentHandler = async() =>{

        let result = await razorPay(total*100);
        if(result.razorpay_payment_id){
            setStatus({
                loading:true,
                isPaid:true
            })
            await course_purchase(user_id,gen_checkout_data(result.razorpay_payment_id));
            setStatus({
                loading:false,
                isPaid:true
            })
        }
        else{
            console.log('result.error: ', result.error);
        }
    }

    const gen_checkout_data = (transaction_id) =>{

        let checkout_data = []

        cartItems.data.map((item)=>{
            checkout_data.push({
                course_id:item.Course.id,
                amount:item.Course.price,
                transaction_id:transaction_id
            })
        });

        return checkout_data;
    }

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Checkout"}
                    onLeftPress={()=>{props.navigation.goBack()}}
                    isRight={false}
                />

                { status.isPaid
                    ?  <CourseBuySuccess loading={status.loading} {...props}/>
                    :<>
                    <View>
                        <View style={{marginHorizontal:16,marginVertical:16}}>
                                <TextComp value={"Order details"} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.xxbig}}/>
                        </View>

                        <View style={{marginHorizontal:10}}>

                            <FlatList
                                data={cartItems.data}
                                renderItem={renderItem}
                            />

                        </View>
                    </View>

                    <View>
                        <View style={{marginHorizontal:16,marginVertical:16}}>
                                <TextComp value={"Summary"} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.xxbig}}/>
                        </View>
                        <View style={{flex:1,alignItems:"center",justifyContent:"center"}}>
                        
                            <View style={{flex:1,flexDirection:"row",alignItems:"center",justifyContent:"center"}}>
                                <View style={{marginHorizontal:10}}>
                                    <TextComp value={"Original Price"} style={{fontSize:size.medium,textAlign:"center",fontFamily:font.bold}} />
                                </View>
                                <View style={{marginHorizontal:10}}>
                                    <TextComp value={`₹ ${total}`} style={{fontSize:size.medium,textAlign:"center"}} />
                                </View>
                            </View>

                            {/* <View style={{flex:1,flexDirection:"row",alignItems:"center",justifyContent:"center",marginTop:10}}>
                                <View style={{marginHorizontal:10}}>
                                    <TextComp value={"Discounts Price"} style={{fontSize:size.medium,textAlign:"center",fontFamily:font.bold}} />
                                </View>
                                <View style={{marginHorizontal:10}}>
                                    <TextComp value={"20.00 ₹"} style={{fontSize:size.medium,textAlign:"center"}} />
                                </View>
                            </View> */}
                        </View>
                    </View>

                    <View>
                        <View style={{marginHorizontal:75,marginVertical:8,flexDirection:"row",alignItems:"center",justifyContent:"center",borderTopColor:color.xgray,borderTopWidth:1.4}}>
                                <TextComp value={"Total"} style={{textAlign:"center",fontFamily:font.bold,fontSize:size.xbig,marginTop:6,marginRight:20}}/>
                                <TextComp value={`₹ ${total}`} style={{textAlign:"center",fontFamily:font.bold,fontSize:size.xbig,marginTop:6}}/>
                        </View>
                    </View>

                    <View style={{flexDirection:"row",marginHorizontal:10,justifyContent:"center",marginTop:16}}>
                        <Button onPress={paymentHandler} value={`PAY ₹ ${total}`} width="80%" buttonStyle={{backgroundColor:color.xblue}} />
                    </View>
                </>
                }

            </ScrollView>

        </SafeAreaView>
    );

};

const mapStateToProps = (state) =>{
    return{
        user_id:state.auth.user.user.id,
        cartItems:state.cart.cartItems
    };
}

const mapDispatchToProps = (dispatch) =>{
    return{
        course_purchase:(user_id,data)=>{dispatch(course_purchase_thunk(user_id,data))}
    };
}
  
export default connect(mapStateToProps,mapDispatchToProps)(Checkout);

const renderItem = ({item,index}) =>{

    const {  Course:{ title, price } } = item;

    return(
        <View key={index} style={{marginBottom:12,padding:4,borderRadius:6,backgroundColor:color.xxgray,padding:18,borderRadius:6}}>

            <View style={{flexDirection:"row"}}>
                <View style={{flex:1,marginHorizontal:10}}>
                    <View style={{flex:1,flexDirection:"row"}}>
                        <View>
                            <TextComp value={`${index+1} .`} style={{fontSize:size.medium,fontFamily:font.bold}} />
                        </View>
                        <View style={{flex:1,marginHorizontal:6}}>
                            <TextComp value={title} style={{fontSize:size.medium,textAlign:"left"}} />
                        </View>
                        <View>
                            <TextComp value={`${price}.00 ₹`} style={{fontSize:size.medium,color:color.black,fontFamily:font.bold}} />
                        </View>
                    </View>
                </View>
            </View>

        </View>
    )
}

const CourseBuySuccess = ({loading,navigation}) =>{

    if(loading){
        return(
            <View style={{flex:1,alignItems:"center",justifyContent:"center"}}>
                <ActivityIndicator animating={loading}  size={50} color={color.xblue} />
                <TextComp value={"Please wait!"} style={{fontSize:size.medium,color:color.black,fontFamily:font.bold}} />
            </View>
        )
    }

    return(
        <View style={{flex:1,alignItems:"center",justifyContent:"center"}}>
            <View>
                <TextComp value={"Purchase completed!"} style={{fontSize:size.xxxbig,color:color.black,fontFamily:font.bold}} />
                <View style={{flexDirection:"row",marginHorizontal:10,justifyContent:"center",marginTop:16}}>
                    <Button onPress={()=>{navigation.navigate(navigator.home)}} value={"GO HOME"} width="80%" buttonStyle={{backgroundColor:color.xblue}} />
                </View>
            </View>
        </View>
    )
}

const calcTotal = (data) => {
    return data.reduce((preVal,curVal)=>(preVal + parseInt(curVal.Course.price)),0);
}