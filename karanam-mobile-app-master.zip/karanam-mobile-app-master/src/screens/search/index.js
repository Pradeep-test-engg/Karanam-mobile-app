import React from 'react';
import SearchPC from './search';

const SearchScreen = () =>{

    return(
        <SearchPC />
    );
}

export default SearchScreen;