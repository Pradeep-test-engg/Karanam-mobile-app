import React, { useState, useEffect } from 'react';
import { SafeAreaView, ScrollView, View, TouchableOpacity, Image, TextInput, FlatList } from 'react-native';
import debounce from 'lodash/debounce';
import StatusBar from '../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../styles/index.js';
import Header from '../../components/header/header';
import CourseResults from './components/courseResults';
import navigator from '../../navigation/navigator';
import { getAllCategorysSrvc } from '../../store/common/services';
import TextComp from '../../components/text/text';
import commonService from '../../store/common/services';
import Loader from '../../components/loader';

const Search = (props) => {

    const [ value, setValue ] = useState("");

    const initialData = {
        query:"",
        loading:false,
        result:{},
        error:null,
    }

    const [ search, setSearch ] = useState(initialData);

    const [ category, setCategory ] = useState([]); 

    useEffect(()=>{
        getInitialData();
    },[])

    const getInitialData = async() =>{
        const result = await getAllCategorysSrvc();
        setCategory(result);
    }

    const handleSearch = async() =>{

        const data = {query:value, page:1, limit:10};

        try {
            setSearch((prev)=>({
                ...prev,
                loading:true,
            }));
            const result = await commonService.searchCourse(data); 
            setSearch((prev)=>({
                ...prev,
                result,
                loading:false,
            }));
        } catch (error) {
            setSearch((prev)=>({
                ...prev,
                loading:false,
                error:error
            }));
        }
    }

    const debounceSearch = debounce(handleSearch,1000);

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Search courses"}
                    onLeftPress={()=>{props.navigation.goBack()}}
                    isRight={false}
                />

                <View style={{flex:1}}>

                <View style={{backgroundColor:color.xxgray,marginHorizontal:14,marginVertical:20,borderRadius:6,flexDirection:"row",alignItems:"center",justifyContent:"space-between"}}>
                    <TextInput onChangeText={(text)=>{setValue(text);debounceSearch()}} value={value} autoFocus={true} placeholder={"Search all courses"} style={{flex:1,textAlign:"left",marginHorizontal:14,paddingVertical:10,fontSize:size.medium,fontFamily:font.bold}}/>
                    <Icon name="search" type="FontAwesome" style={{fontSize:size.big,right:20}}  />
                </View>

                {
                    search.loading && <Loader />
                }

                {
                    value.length > 0
                    ? <CourseResults onPress={()=>props.navigation.navigate(navigator.CourseBuy)} data= {search.result.data ? search.result.data : [] }/>
                    :   <> 
                            <View style={{marginHorizontal:14,marginVertical:20}}>
                                <TextComp value={"Browse categories"} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.big}} />
                            </View>

                            <FlatList
                                data={category}
                                renderItem = { ({item,index}) => <Category navigation={props.navigation} data={item} index={index} /> }
                            />
                        </>
                }

                </View>

            </ScrollView>

        </SafeAreaView>
    );

};

export default Search;

const Category = ({ data,  index, navigation }) =>{

    const { name, isOpen, sub_categories } = data;

    return(
        <>
        <TouchableOpacity style={{backgroundColor:color.xxgray,marginHorizontal:14,marginVertical:6,borderRadius:6,flexDirection:"row",alignItems:"center",justifyContent:"space-between"}}
            >
            <TextComp value={name} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.big,paddingVertical:12,marginLeft:10}}/>
                {
                    sub_categories && 
                    <>
                        {
                            true
                            ? <Icon name="chevron-right" type="MaterialIcons" style={{fontSize:size.xxxbig,right:10}} /> 
                            : <Icon name="keyboard-arrow-down" type="MaterialIcons" style={{fontSize:size.xxxbig,right:10}} />
                        }
                    </>
                }
                
        </TouchableOpacity>
        { isOpen && sub_categories ?
                sub_categories.map((subCat,index)=>{
                    return(
                        <TouchableOpacity style={{marginHorizontal:14,borderRadius:6,marginBottom:4}} key={index}
                            onPress={()=>{navigation.navigate(navigator.CourseList,{id:subCat.id,details:subCat})}}>
                            <View style={{backgroundColor:"lightblue",marginLeft:14,paddingVertical:8,borderRadius:6,flexDirection:"row",alignItems:"center",justifyContent:"space-around"}}>
                                <View style={{borderRadius:6}}>
                                    <TextComp value={subCat.name} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.medium}}/>
                                </View>
                            </View>
                        </TouchableOpacity>
                    )
                })
            : null 
        }
        </>
    )
}