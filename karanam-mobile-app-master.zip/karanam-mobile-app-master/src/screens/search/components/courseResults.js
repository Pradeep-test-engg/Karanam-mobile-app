import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, TouchableOpacity, Image } from 'react-native';
import StatusBar from '../../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../../styles/index.js';
import TextComp from '../../../components/text/text';
import { FlatList } from 'react-native-gesture-handler';

const CourseResults = ({onPress,data}) => {

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <View style={{flex:1}}>

                    <View style={{marginHorizontal:10}}>

                        <FlatList
                            data={data}
                            renderItem={({item,index})=>(
                                <RenderItem item={item} key={index} onPress={onPress} />
                            )}
                            onEndReached={()=>{console.log("end reached");}}
                            ListHeaderComponent={data.length > 0 && <View style={{marginBottom:20}}><TextComp value={`${data.length} courses found`} /></View>}
                            ListEmptyComponent={<View><TextComp value={"No Results found!"} /></View>}
                        />

                    </View>

                </View>
            </ScrollView>

        </SafeAreaView>
    );

};

export default CourseResults;

const RenderItem = ({item,key,onPress}) =>{

    return(
        <TouchableOpacity key={key} style={{backgroundColor:color.xxgray,marginBottom:12,padding:10,borderRadius:6}} onPress={onPress}>
            <View style={{flexDirection:"row",alignItems:"center"}}>
                <View style={{height:55,width:55}}>
                    <Image source={{uri:item.thumbnail}} style={{height:"100%",width:"100%",borderRadius:6}} />
                </View>
                <View style={{flex:1}}>
                    <View>
                        <TextComp value={item.title} style={{textAlign:"center",fontSize:size.small,fontFamily:font.bold}}/>
                        <TextComp value={item.short_description} style={{color:color.xgray,fontSize:size.small,marginTop:4}}/>
                    </View>
                </View>
            </View>
        </TouchableOpacity>
    )
}
