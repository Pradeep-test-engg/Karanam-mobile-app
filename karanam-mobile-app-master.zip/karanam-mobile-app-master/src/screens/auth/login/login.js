import React, { useState } from 'react';
import { View, SafeAreaView, TextInput, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { color, font, size, Icon } from '../../../styles/index.js';
import StatusBar from './../../../components/statusbar/statusbar';
import TextComp from './../../../components/text/text';
import Button from './../../../components/button/button';
import navigator from './../../../navigation/navigator';
import validator from './../../../utils/validator';
import { loginEmailThunk } from '../../../store/auth/thunk';
import { connect } from 'react-redux';

const Login = (props) => {

    const initialState = {
        user_name:"",
        password:"",
    }

    const errors = {
        user_name:false,
        password:false,
        common:false,
    }

    const [ data, setData ] = useState(initialState);

    const [ error, setError ] = useState(errors);

    const handleInputChange = async(name,value) =>{
        setData({
            ...data,
            [name]:value,
        })

        const is_error = validator.isFilled(name,value);

        if(is_error){
            setError({
                ...error,
                [name]:is_error
            })
        }
        else{
            setError({
                ...error,
                [name]:false
            })
        }
    }

    const handleSignIn = async() =>{

        const is_error = validator.isObjFilled("",data);

        if(!is_error){
            setError({
                ...error,
                common:false
            })

            await props.loginEmail({ email:data.user_name, password:data.password});

        }else{
            setError({
                ...error,
                common:is_error
            })
        }

    }

    if(false){
        return(
        <View style={{alignItems:"center",justifyContent:"center",flex:1}}>
            <ActivityIndicator animating={true} size={40} color={color.xblue} />
        </View>
        )
    }

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1}}>

                <View style={{flex:1,justifyContent:"center"}}>

                    <View style={{height:140,alignItems:"flex-start"}}>
                        <TextComp value="Welcome" style={{color:color.black,left:30,top:30,fontFamily:font.bold,fontSize:size.xxxxbig}}/>
                        <TextComp value="sign in to continue" style={{color:color.black,left:30,top:40,fontFamily:font.regular,fontSize:size.xbig}}/>
                    </View>

                </View>

                <View style={{flex:2,backgroundColor:"white",justifyContent:"space-around"}}>

                    <View style={{flex:1,justifyContent:"space-around"}}>

                        <View style={{justifyContent:"flex-start",marginHorizontal:20}}>

                            <TextComp value="Enter user name and password" style={{color:color.xgray,textAlign:"left",left:10,fontSize:size.big,fontFamily:font.bold}}/>

                            <View style={{backgroundColor:color.xxgray,height:50,borderRadius:4,marginVertical:10,flexDirection:"row",alignItems:"center"}}>

                                <Icon type="FontAwesome5" name="user-circle" color={color.xblue} size={size.big} style={{color:color.xgray,textAlign:"left",left:10,fontSize:size.medium,fontFamily:font.bold}} />
                                <TextInput style={{flex:1,color:color.black,marginHorizontal:10,fontSize:size.big,fontFamily:font.regular,marginLeft:30,fontSize:size.medium}} 
                                    placeholder="user name"
                                    value={data.user_name}
                                    onChangeText={(value)=>{handleInputChange("user_name",value)}} 
                                />

                            </View>

                            {
                                error.user_name ?
                                <TextComp value={error.user_name} style={{color:color.red,textAlign:"center",fontSize:size.medium}}/>
                                : null
                            }

                            <View style={{backgroundColor:color.xxgray,height:50,borderRadius:4,marginVertical:10,flexDirection:"row",alignItems:"center"}}>

                                <Icon type="Fontisto" name="locked" color={color.xblue} size={size.big} style={{color:color.xgray,textAlign:"left",left:10,fontSize:size.medium,fontFamily:font.bold}} />
                                <TextInput  style={{flex:1,color:color.black,marginHorizontal:10,fontSize:size.big,fontFamily:font.regular,marginLeft:30,fontSize:size.medium}} secureTextEntry={true} 
                                    placeholder="password"
                                    value={data.password}
                                    onChangeText={(value)=>{handleInputChange("password",value)}} 
                                />

                            </View>

                            {
                                error.password ?
                                <TextComp value={error.password} style={{color:color.red,textAlign:"center",fontSize:size.medium}}/>
                                : null
                            }

                            {
                                error.common ?
                                <TextComp value={error.common} style={{color:color.red,textAlign:"center",fontSize:size.medium,marginTop:8}}/>
                                : null
                            }

                            <View style={{height:30,flexDirection:"row",alignItems:"center",justifyContent:"space-around"}}>
                                <TouchableOpacity onPress={()=>{props.navigation.navigate(navigator.forgotPswd)}}>
                                    <TextComp value="forgot password ?" style={{color:color.black,fontSize:size.small}}/>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={()=>{props.navigation.navigate(navigator.LoginOtp)}}>
                                    <TextComp value="login with otp ?" style={{color:color.black,fontSize:size.small}}/>
                                </TouchableOpacity>
                            </View>

                        </View>

                        <View style={{flex:2,backgroundColor:"white",alignItems:"center",justifyContent:"flex-start",marginTop:18}}>
                            <Button value={"Sign in"} onPress={handleSignIn} width={"90%"} buttonStyle={{paddingVertical:12}} textStyle={{fontSize:size.big}} />
                        </View>

                    </View>

                </View>

                <View style={{flex:1,backgroundColor:"white",justifyContent:"center",alignItems:"center"}}>

                    <Button value={"Create new account"} width="80%" onPress={()=>{props.navigation.navigate(navigator.signUp)}} buttonStyle={{backgroundColor:color.white}} textStyle={{color:color.black,fontSize:size.big}} />

                </View>

            </ScrollView>

        </SafeAreaView>
    );

};

const mapDispatchToProps = (dispatch) =>{

    return{
      loginEmail:(data)=>{dispatch(loginEmailThunk(data))}
    }
  
  }
  
export default connect(null,mapDispatchToProps)(Login);