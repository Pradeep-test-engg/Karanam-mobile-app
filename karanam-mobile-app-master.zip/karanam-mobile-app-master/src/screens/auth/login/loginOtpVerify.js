import React, { useState, useEffect } from 'react';
import { View, KeyboardAvoidingView, ScrollView, SafeAreaView, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import OTPInputView from '@twotalltotems/react-native-otp-input'
import { color, font, size, Icon } from '../../../styles/index.js';
import text from '../../../utils/text';
import Header from '../../../components/header/header';
import StatusBar from '../../../components/statusbar/statusbar';
import Button from '../../../components/button/button';
import TextComp from '../../../components/text/text';
import { connect } from 'react-redux';
import { loginVerifyOtpThunk } from '../../../store/auth/thunk';

const LoginOtpVerify = (props) => {

  return (
    <SafeAreaView style={{flex:1}}>

    <ScrollView style={{flex:1,backgroundColor:color.white}} contentContainerStyle={{flexGrow:1}}>

        <StatusBar />

        <Header
            textCenter={"OTP Verification"}
            onLeftPress={()=>{props.navigation.goBack()}}
            isRight={false}
        />

        <View style={{justifyContent:"center"}}>

            <View style={{height:100,alignItems:"flex-start",justifyContent:"center"}}>
                <View style={{flexDirection:"row",alignItems:"center",left:30,top:30}}>
                    <TextComp value="OTP Sent" style={{color:color.black,fontFamily:font.bold,fontSize:size.xxxbig,marginRight:10}}/>
                    <Icon type="MaterialCommunityIcons" name="check-decagram" color={color.xblue} size={size.xxbig} />
                </View>
                <View style={{flexDirection:"row",alignItems:"center",left:30,top:40}}>
                    <TextComp value="4 digit otp sent ot 9999222230" style={{color:color.black,fontFamily:font.regular,fontSize:size.medium,marginRight:10}}/>
                    <TouchableOpacity onPress={()=>{props.navigation.goBack()}}>
                        <Icon type="FontAwesome" name="edit" color={color.xblue} size={size.big} />
                    </TouchableOpacity>
                </View>
            </View>

        </View>

      <KeyboardAvoidingView style={{flex:1}}>

        <View style={{flex:1,marginHorizontal:23,marginTop:70}}>

            <TextComp value="enter 4 digit otp" style={{color:color.xgray,textAlign:"left",left:10,fontSize:size.big,fontFamily:font.bold}}/>

            <View style={{borderRadius:4,marginVertical:10,flexDirection:"row",alignItems:"center",justifyContent:"center"}}>

                <OTPInputView
                    pinCount={6} 
                    style={{width: '80%', height: 60}}
                    codeInputFieldStyle={{marginHorizontal:2,color:"black"}}
                    onCodeFilled={ (otp) => props.verifyOtp({phone:props.route.params.phone,otp:otp})}
                />

            </View>

            <TouchableOpacity>
                <TextComp value="Resend otp ?" style={{color:color.xgray,textAlign:"right",right:10,fontSize:size.small}}/>
            </TouchableOpacity>

            {/* <View style={{alignItems:"center",marginTop:18}}>

                <Button
                    value={"Verify OTP"}
                    buttonStyle={{backgroundColor:color.xblue}}
                    textStyle={{color:color.white}}
                    width="100%"
                />

            </View> */}

        </View>

      </KeyboardAvoidingView>

    </ScrollView>
    </SafeAreaView>
  )
};


const mapDispatchToProps = (dispatch) =>{

  return{
    verifyOtp:(data)=>{dispatch(loginVerifyOtpThunk(data))}
  }

}

export default connect(null,mapDispatchToProps)(LoginOtpVerify);

const styles = StyleSheet.create({
    borderStyleBase: {
      width: 30,
      height: 45
    },
   
    borderStyleHighLighted: {
      borderColor: "#03DAC6",
    },
   
    underlineStyleBase: {
      width: 30,
      height: 45,
      borderWidth: 0,
      borderBottomWidth: 1,
    },
   
    underlineStyleHighLighted: {
      borderColor: "#03DAC6",
    },
  });
   