import React, { useState, useEffect } from 'react';
import { View, KeyboardAvoidingView, ScrollView, SafeAreaView, TextInput } from 'react-native';
import { color, font, size, Icon } from '../../../styles/index.js';
import text from './../../../utils/text';
import Header from './../../../components/header/header';
import StatusBar from '../../../components/statusbar/statusbar';
import Button from './../../../components/button/button';
import TextComp from './../../../components/text/text';

const forgotPswd = (props) => {

  return (
    <SafeAreaView style={{flex:1}}>

    <ScrollView style={{flex:1,backgroundColor:color.white}} contentContainerStyle={{flexGrow:1}}>

        <StatusBar />

        <Header
            textCenter={text.forgotPswd}
            onLeftPress={()=>{props.navigation.goBack()}}
            isRight={false}
        />

        <View style={{justifyContent:"center"}}>

            <View style={{height:80,alignItems:"flex-start",justifyContent:"center"}}>
                <TextComp value="Forgot password" style={{color:color.black,left:30,top:30,fontFamily:font.bold,fontSize:size.xxxbig}}/>
                <TextComp value="enter your user name" style={{color:color.black,left:30,top:40,fontFamily:font.regular,fontSize:size.medium}}/>
            </View>

        </View>

      <KeyboardAvoidingView style={{flex:1}}>

        <View style={{flex:1,marginHorizontal:23,marginTop:80}}>

            <TextComp value="user name" style={{color:color.xgray,textAlign:"left",left:10,fontSize:size.big,fontFamily:font.bold}}/>

            <View style={{backgroundColor:color.xxgray,height:50,borderRadius:4,marginVertical:10,flexDirection:"row",alignItems:"center"}}>

                <Icon type="FontAwesome5" name="user-circle" color={color.xblue} size={size.big} style={{color:color.xgray,textAlign:"left",left:10,fontSize:size.medium,fontFamily:font.bold}} />
                <TextInput style={{flex:1,color:color.black,marginHorizontal:10,fontSize:size.big,fontFamily:font.regular,marginLeft:30,fontSize:size.medium,fontFamily:font.bold}} keyboardType="phone-pad" />

            </View>

            <TextComp value="A password reset link will be sent to associated email with user name given" style={{color:color.xgray,textAlign:"left",left:10,fontSize:size.xsmall}}/>

            <View style={{alignItems:"center",marginTop:24}}>

                <Button
                    value={"Reset password"}
                    buttonStyle={{backgroundColor:color.xblue}}
                    textStyle={{color:color.white}}
                    width="100%"
                />

            </View>

        </View>

      </KeyboardAvoidingView>

    </ScrollView>
    </SafeAreaView>
  )
};

export default forgotPswd;