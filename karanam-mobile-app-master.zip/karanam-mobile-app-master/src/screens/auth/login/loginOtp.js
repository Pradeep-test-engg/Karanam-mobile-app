import React, { useState, useEffect } from 'react';
import { View, KeyboardAvoidingView, ScrollView, SafeAreaView, TextInput } from 'react-native';
import { color, font, size, Icon } from '../../../styles/index.js';
import text from '../../../utils/text';
import Header from '../../../components/header/header';
import StatusBar from '../../../components/statusbar/statusbar';
import Button from '../../../components/button/button';
import TextComp from '../../../components/text/text';
import navigator from '../../../navigation/navigator';
import { connect } from 'react-redux';
import { loginSendOtpThunk } from '../../../store/auth/thunk';

const LoginOtp = (props) => {

  const [ data, setData ] = useState(null);

  const handleSendOtp = async() =>{
    await props.sendOtp({phone:data});
    await props.navigation.navigate(navigator.LoginOtpVerify,{phone:data})
  }

  return (
    <SafeAreaView style={{flex:1}}>

    <ScrollView style={{flex:1,backgroundColor:color.white}} contentContainerStyle={{flexGrow:1}}>

        <StatusBar />

        <Header
            textCenter={text.loginOtp}
            onLeftPress={()=>{props.navigation.goBack()}}
            isRight={false}
        />

        <View style={{justifyContent:"center"}}>

            <View style={{height:80,alignItems:"flex-start",justifyContent:"center"}}>
                <TextComp value="Your Phone" style={{color:color.black,left:30,top:30,fontFamily:font.bold,fontSize:size.xxxbig}}/>
                <TextComp value="enter your phone number" style={{color:color.black,left:30,top:40,fontFamily:font.regular,fontSize:size.medium}}/>
            </View>

        </View>

      <KeyboardAvoidingView style={{flex:1}}>

        <View style={{flex:1,marginHorizontal:23,marginTop:80}}>

            <TextComp value="Phone number" style={{color:color.xgray,textAlign:"left",left:10,fontSize:size.big,fontFamily:font.bold}}/>

            <View style={{backgroundColor:color.xxgray,height:50,borderRadius:4,marginVertical:10,flexDirection:"row",alignItems:"center"}}>

                <TextComp value="+91" style={{color:color.xgray,textAlign:"left",left:10,fontSize:size.medium,fontFamily:font.bold}}/>
                <TextInput onChangeText={(value)=>{setData(value)}} style={{flex:1,color:color.black,marginHorizontal:10,fontSize:size.big,fontFamily:font.regular,marginLeft:30,fontSize:size.medium,fontFamily:font.bold}} keyboardType="phone-pad" />

            </View>

            <TextComp value="A 4 digit otp will be sent via sms to verify your phone number" style={{color:color.xgray,textAlign:"left",left:10,fontSize:size.xsmall}}/>

            <View style={{alignItems:"center",marginTop:24}}>

                <Button
                    value={"Send OTP"}
                    buttonStyle={{backgroundColor:color.xblue}}
                    textStyle={{color:color.white}}
                    width="100%"
                    onPress={handleSendOtp}
                />

            </View>

        </View>

      </KeyboardAvoidingView>

    </ScrollView>
    </SafeAreaView>
  )
};

const mapDispatchToProps = (dispatch) =>{

  return{
    sendOtp:(data)=>{dispatch(loginSendOtpThunk(data))}
  }

}

export default connect(null,mapDispatchToProps)(LoginOtp);
