import React, { useState } from 'react';
import { View, KeyboardAvoidingView, ScrollView, SafeAreaView, ActivityIndicator } from 'react-native';
import OTPInputView from '@twotalltotems/react-native-otp-input';
import { Formik } from 'formik';
import { color, font, size, Icon } from '../../../styles/index.js';
import initialState from './utils/initialState';
import StatusBar from '../../../components/statusbar/statusbar';
import Step from '../../../components/steps/steps';
import Button from '../../../components/button/button';

export default (props) => {

  const {
    currentStep,
    labels,
    handleStepChange,
    FormComp,
    } = props;

  console.log(currentStep);

  return (
    <SafeAreaView style={{flex:1}}>

    <ScrollView style={{flex:1,backgroundColor:color.white}} contentContainerStyle={{flexGrow:1}}>

    <Formik
      initialValues={initialState}
      enableReinitialize={true}
      onSubmit={ () =>{ console.log("submitting") ;handleStepChange("next") ;}}
      // validationSchema={}
      >
      {({ handleChange, 
                handleBlur, 
                handleSubmit, 
                setFieldValue,
                values, 
                errors,
                touched,
                isValid,
                ...props
                }) => {
                console.log(values);
                return(
                  <>
      <View style={{flex:1}}>

        <View style={{flex:1,justifyContent:"center",marginHorizontal:16,marginVertical:16}}>
          <Step
            labels={labels}
            currentPosition={currentStep}
            stepCount={labels.length}
          />
        </View>

      </View>

      <KeyboardAvoidingView style={{flex:4}}>

        <View style={{flex:1,backgroundColor:"white",marginHorizontal:23}}>

        <FormComp 
          values={values} 
          handleChange={handleChange} 
          handleBlur={handleBlur} 
          errors={errors} 
          touched={touched} 
          setFieldValue={setFieldValue}
        />

        </View>

      </KeyboardAvoidingView>

      <View style={{height:80,zIndex:-10}}>

        <View style={{flex:1,flexDirection:"row",alignItems:"center",justifyContent:"space-around",zIndex:-10}}>

        { currentStep != 0 && 
          <Button
            value={"Previous step"}
            onPress={()=>{handleStepChange("prev")}}
            buttonStyle={{paddingVertical:10,paddingHorizontal:30,backgroundColor:color.white}}
            textStyle={{color:color.xgray}}
            />
        }

          <Button 
            value={"Next step"}
            buttonStyle={{paddingVertical:10,paddingHorizontal:40}}
            onPress={handleSubmit}
          />

        </View>

      </View>
        </>
      )}}
      </Formik>

    </ScrollView>
    </SafeAreaView>
  )
};
