import validator from '../../../../utils/validator';

export const signUpFieldValidate = async(name,value,error,setError) => {
    
    let isError;

    const setErrorBasic = async(name,isError) =>{
        await setError({
            ...error,
            basicInfo:{
                ...error.basicInfo,
                [name]:isError ? isError : false,
            },
        });
    }

    const setErrorCreds = async(name,isError) =>{
        await setError({
            ...error,
            credential:{
                ...error.credential,
                [name]:isError ? isError : false,
            },
        });
    }

    const setErrorId = async(name,isError) =>{
        await setError({
            ...error,
            idDetails:{
                ...error.idDetails,
                [name]:isError ? isError : false,
            },
        });
    }

    const setErrorEdu = async(name,isError) =>{
        await setError({
            ...error,
            education:{
                ...error.education,
                [name]:isError ? isError : false,
            },
        });
    }

    const setErrorWrkExp = async(name,isError) =>{
        await setError({
            ...error,
            wpExperience:{
                ...error.wpExperience,
                [name]:isError ? isError : false,
            },
        });
    }

    switch(name){

        // STEP 1
        case "fName":
            isError = validator.isFilled("first name", value,4);
            await setErrorBasic(name,isError);
            break;

        case "lName":
            isError = validator.isFilled("last name", value,4);
            await setErrorBasic(name,isError);
            break;

        case "address":
            isError = validator.isFilled("address", value,20);            
            await setErrorBasic(name,isError);
            break;

        case "email":
            isError = validator.isEmail(value, value);            
            await setErrorBasic(name,isError);
            break;


        // STEP 2
        case "profession":
            isError = validator.isFilled("profession", value);
            await setErrorCreds(name,isError);
            break;

        case "usrName":
            isError = validator.isFilled("usrName", value,4);
            await setErrorCreds(name,isError);
            break;

        case "phone":
            isError = validator.isNumber("phone", value,10);
            await setErrorCreds(name,isError);
            break;

        case "pswd":
            isError = validator.isFilled("pswd", value,8);
            await setErrorCreds(name,isError);
            break;

        // STEP 3
        case "adhar":
            isError = validator.isNumber("adhar", value,12);
            await setErrorId(name,isError);
            break;

        case "pan":
            isError = validator.isFilled("pan", value,10);
            await setErrorId(name,isError);
            break;

        case "passport":
            isError = validator.isNumber("passport", value,6);
            await setErrorId(name,isError);
            break;

        case "workPermit":
            isError = validator.isFilled("workPermit", value);
            await setErrorId(name,isError);
            break;
        
        case "wpContry":
            isError = validator.isFilled("wpContry", value);
            await setErrorId(name,isError);
            break;

        case "wpNumber":
            isError = validator.isNumber("wpNumber", value,6);
            await setErrorId(name,isError);
            break;


        // STEP 4
        case "sslcScl":
            isError = validator.isFilled("sslc school", value);
            await setErrorEdu(name,isError);
            break;

        case "sslcPrct":
            isError = validator.isFilled("sslc percentage", value);
            await setErrorEdu(name,isError);
            break;

        case "pucCol":
            isError = validator.isFilled("puc college", value);
            await setErrorEdu(name,isError);
            break;

        case "pucPrct":
            isError = validator.isFilled("puc percentage", value);
            await setErrorEdu(name,isError);
            break;
        
        case "fnshDegree":
            isError = validator.isFilled("finished degree", value);
            await setErrorEdu(name,isError);
            break;

        case "degree":
            isError = validator.isFilled("degree", value);
            await setErrorEdu(name,isError);
            break;

        case "dCollege":
            isError = validator.isFilled("degree ollege", value);
            await setErrorEdu(name,isError);
            break;

        case "dPct":
            isError = validator.isFilled("degree percentage", value);
            await setErrorEdu(name,isError);
            break;

        case "searchJob":
            isError = validator.isFilled("searching job", value);
            await setErrorEdu(name,isError);
            break;

        // STEP 5 - Work experience

        case "crntOrg":
            isError = validator.isFilled("current organization", value);
            await setErrorWrkExp(name,isError);
            break;

        case "Dsgn":
            isError = validator.isFilled("Designation", value);
            await setErrorWrkExp(name,isError);
            break;

        case "intrstInHighEdu":
            isError = validator.isFilled("higher education", value);
            await setErrorWrkExp(name,isError);
            break;

        case "choose":
            isError = validator.isFilled("higher education", value);
            await setErrorWrkExp(name,isError);
            break;
        
        case "intrstInDmnChng":
            isError = validator.isFilled("domain change", value);
            await setErrorWrkExp(name,isError);
            break;

        case "dmnComments":
            isError = validator.isFilled("domains", value);
            await setErrorWrkExp(name,isError);
            break;

        case "intrstInOrgChng":
            isError = validator.isFilled("organization change", value);
            await setErrorWrkExp(name,isError);
            break;

        case "orgComments":
            isError = validator.isFilled("organization comments", value);
            await setErrorWrkExp(name,isError);
            break;

        case "intrstSkills":
            isError = validator.isFilled("intrested skills", value);
            await setErrorWrkExp(name,isError);
            break;
    }
}
 
export const signUpformValidate = (data,error,type) =>{

    let errors = Object.getOwnPropertyNames(error[type]);

    let isError = false;

    if(type == "education"){

        data["fnshDegree"] == "Yes"
        ? errors = ["sslcScl", "sslcPrct", "pucCol", "pucPrct", "fnshDegree", "degree", "dCollege", "dPct", "searchJob"]
        : errors = ["sslcScl", "sslcPrct", "pucCol", "pucPrct", "fnshDegree" ];

        errors.map((dataKey) =>{
            if(!data[dataKey] || error[type][dataKey]){
                isError=true;
            }
        });

        return isError;
    }

    if(type == "idDetails"){

        data["workPermit"] == "Yes"
        ? errors = ["adhar", "pan", "passport", "workPermit", "wpContry", "wpNumber", "startDate", "endDate"] 
        : errors = ["adhar", "pan", "passport", "workPermit"];

        errors.map((dataKey) =>{
            if(!data[dataKey] || error[type][dataKey]){
                isError=true;
            }
        });

        return isError;
    }

    errors.map((dataKey) =>{

        if(!data[dataKey] || error[type][dataKey]){
            isError=true;
        }

    });

    return isError;
}