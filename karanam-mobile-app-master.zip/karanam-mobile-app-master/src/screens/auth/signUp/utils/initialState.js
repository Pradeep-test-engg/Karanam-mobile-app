export default {

    first_name: "",
    last_name:"",
    gender:"",
    address:"",
    state:"",
    city:"",
    dob:"",

}
