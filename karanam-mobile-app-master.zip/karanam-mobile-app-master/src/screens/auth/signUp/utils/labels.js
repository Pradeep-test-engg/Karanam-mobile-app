export const labels = ["Basic Info","Credential","ID Details","Education","Experience"];

export const studentLabels = ["Basic Info","Credential","ID Details","Education"];