import BasicInfo from '../components/basicInfo';
import Credential from '../components/credential';
import IdDetails from '../components/idDetails';
import Education from '../components/education';
import WPExperience from '../components/wpExperience';
import DomnExpert from '../components/domnExpert';

export const studntStepData = {
    0:{
        stepNumber:0,
        name:"basicInfo",
        stepComponent:BasicInfo,
    },
    1:{
        stepNumber:1,
        name:"credential",
        stepComponent:Credential,
    },
    2:{
        stepNumber:2,
        name:"idDetails",
        stepComponent:IdDetails,
    },
    3:{
        stepNumber:3,
        name:"education",
        stepComponent:Education,
    },
};

export const wrkExpStepData = {
    0:{
        stepNumber:0,
        name:"basicInfo",
        stepComponent:BasicInfo,
    },
    1:{
        stepNumber:1,
        name:"credential",
        stepComponent:Credential,
    },
    2:{
        stepNumber:2,
        name:"idDetails",
        stepComponent:IdDetails,
    },
    3:{
        stepNumber:3,
        name:"education",
        stepComponent:Education,
    },
    4:{
        stepNumber:4,
        name:"wpExperience",
        stepComponent:WPExperience,
    },
};

export const dmnExprtStepData = {
    0:{
        stepNumber:0,
        name:"basicInfo",
        stepComponent:BasicInfo,
    },
    1:{
        stepNumber:1,
        name:"credential",
        stepComponent:Credential,
    },
    2:{
        stepNumber:2,
        name:"idDetails",
        stepComponent:IdDetails,
    },
    3:{
        stepNumber:3,
        name:"education",
        stepComponent:Education,
    },
    4:{
        stepNumber:4,
        name:"dmnExpert",
        stepComponent:DomnExpert,
    },
};