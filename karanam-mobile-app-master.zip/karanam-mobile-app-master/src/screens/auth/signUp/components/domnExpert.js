import React, { useEffect } from 'react';
import { View, SafeAreaView } from 'react-native';
import text from '../../../../utils/text';
import TextInputA from '../../../../components/textInput/textInputA';
import Dropdown from '../../../../components/dropdown/dropdown';


const DomnExpert = ({ data = {}, handleChange }) => {

  const {
    workExrnce,
    setAptPaper,
    emotionIQ,
    emotionCmnts,
    condctPrsnlIntrv,
    condctPrsnIntrvCount,
    recruitment,
    intrstInReviewQustn
    } = data;

    let dmnExpert = {}

  return (
    <SafeAreaView style={{flex:1}}>

        <View style={{flex:1,backgroundColor:"white"}}>

          <TextInputA placeholder="work experience" value={workExrnce} name="workExrnce" onChangeText={(value)=>{handleChange("workExrnce",value)}} isError={dmnExpert.workExrnce} />
          
          <Dropdown
                placeholder="Set Aptitude Paper"
                items={[
                  {label: 'Yes', value: 'Yes'},
                  {label: 'No', value: 'No', },
              ]}
              onChangeItem={(value)=>{handleChange("setAptPaper",value.value)}}
              label ={ setAptPaper ? "setAptPaper" : false }
              value={setAptPaper}
              isError={dmnExpert.setAptPaper}
            />

          <Dropdown
                  placeholder="Intrested to review questions"
                  items={[
                    {label: 'Yes', value: 'Yes'},
                    {label: 'No', value: 'No', },
                ]}
                onChangeItem={(value)=>{handleChange("intrstInReviewQustn",value.value)}}
                label ={ intrstInReviewQustn ? "Intrested to review questions" : false }
                value={intrstInReviewQustn}
                isError={dmnExpert.intrstInReviewQustn}
              />

          <Dropdown
                placeholder="Emotional IQ"
                items={[
                  {label: 'Yes', value: 'Yes'},
                  {label: 'No', value: 'No', },
              ]}
              onChangeItem={(value)=>{handleChange("emotionIQ",value.value)}}
              label ={ emotionIQ ? "Emotional IQ" : false }
              value={emotionIQ}
              isError={dmnExpert.emotionIQ}
            />

            {
              emotionIQ == "Yes" ?
              <TextInputA placeholder="Emotional IQ Comments" value={emotionCmnts} name="emotionCmnts" onChangeText={(value)=>{handleChange("emotionCmnts",value)}} isError={dmnExpert.emotionCmnts} />
              : null
            }
             
            <Dropdown
                placeholder="Conducted personal interview"
                items={[
                  {label: 'Yes', value: 'Yes'},
                  {label: 'No', value: 'No', },
              ]}
              onChangeItem={(value)=>{handleChange("condctPrsnlIntrv",value.value)}}
              label ={ condctPrsnlIntrv ? "Conducted personal interview" : false }
              value={condctPrsnlIntrv}
              isError={dmnExpert.condctPrsnlIntrv}
            />

            <TextInputA placeholder="How many personal interview conducted" keyboardType="number-pad" value={condctPrsnIntrvCount} name="condctPrsnIntrvCount" onChangeText={(value)=>{handleChange("condctPrsnIntrvCount",value)}} isError={dmnExpert.condctPrsnIntrvCount} />

            <TextInputA placeholder="How many recruitment" keyboardType="number-pad" value={recruitment} name="recruitment" onChangeText={(value)=>{handleChange("recruitment",value)}} isError={dmnExpert.recruitment} />

        </View>

    </SafeAreaView>
  )
};

export default DomnExpert;