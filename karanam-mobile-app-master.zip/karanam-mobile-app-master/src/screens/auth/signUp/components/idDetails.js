import React, { useState, useEffect } from 'react';
import { View, SafeAreaView } from 'react-native';
import text from '../../../../utils/text';
import TextInputA from '../../../../components/textInput/textInputA';
import Dropdown from '../../../../components/dropdown/dropdown';
import DatePick from '../../../../components/datepicker/datepicker';

const IdDetails = ({ data = {}, handleChange  }) => {

  const {
    adhar,
    pan,
    passport,
    workPermit,
    wpContry,
    wpNumber,
    startDate,
    endDate,
    } = data;

    let idDetails = {};

  return (
    <SafeAreaView style={{flex:1}}>

        <View style={{flex:1,backgroundColor:"white"}}>

          <TextInputA placeholder="Adhar number" keyboardType="number-pad" value={adhar} name="adhar" onChangeText={(value)=>{handleChange("adhar",value)}} isError={idDetails.adhar} />
          <TextInputA placeholder="Pan number"  value={pan} name="pan" onChangeText={(value)=>{handleChange("pan",value)}} isError={idDetails.pan}/>
          <TextInputA placeholder="Passport number" value={passport} name="passport" onChangeText={(value)=>{handleChange("passport",value)}} isError={idDetails.passport} />

          <Dropdown
              placeholder="Do you have work permit"
              items={[
                {label: 'Yes', value: 1},
                {label: 'No', value: 0, },
              ]}
              onChangeItem={(value)=>{handleChange("workPermit",value.value)}}
              label ={ workPermit ? "workPermit" : false }
              value={workPermit}
              isError={idDetails.workPermit}
          />

          {
            workPermit ?
            <>
              <TextInputA placeholder="Work permit country" value={wpContry} name="wpContry" onChangeText={(value)=>{handleChange("wpContry",value)}} isError={idDetails.wpContry} />
              <TextInputA placeholder="Work permit number" value={wpNumber} name="wpNumber" onChangeText={(value)=>{handleChange("wpNumber",value)}} isError={idDetails.wpNumber} />
              
              <DatePick
                handleChange={handleChange}
                name={"startDate"}
                value={startDate}
                label={"Start Date"}
                placeHolder={"Select start date"}
              />

              <DatePick
                handleChange={handleChange}
                name={"endDate"}
                value={endDate}
                label={"End Date"}
                placeHolder={"Select end date"}
              />

            </>
            : null 
          }

        </View>

    </SafeAreaView>
  )
};

export default IdDetails;