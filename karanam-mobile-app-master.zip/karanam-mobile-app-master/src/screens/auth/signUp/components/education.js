import React, { useEffect } from 'react';
import { View, SafeAreaView } from 'react-native';
import text from '../../../../utils/text';
import TextInputA from '../../../../components/textInput/textInputA';
import Dropdown from '../../../../components/dropdown/dropdown';

const Education = ({ data = {}, handleChange }) => {

  const {
    sslcScl,
    sslcPrct,
    pucCol,
    pucPrct,
    fnshDegree,
    degree,
    dCollege,
    dPct,
    searchJob,
    } = data;

    let education ={}

  return (
    <SafeAreaView style={{flex:1}}>

        <View style={{flex:1,backgroundColor:"white"}}>

          <TextInputA placeholder="SSLC school" value={sslcScl} name="sslcScl" onChangeText={(value)=>{handleChange("sslcScl",value)}} isError={education.sslcScl} />
          <TextInputA placeholder="SSLC %" keyboardType="number-pad" value={sslcPrct} name="sslcPrct" onChangeText={(value)=>{handleChange("sslcPrct",value)}} isError={education.sslcPrct} />
          <TextInputA placeholder="PUC college"  value={pucCol} name="pucCol" onChangeText={(value)=>{handleChange("pucCol",value)}} isError={education.pucCol}/>
          <TextInputA placeholder="PUC %" keyboardType="number-pad" value={pucPrct} name="pucPrct" onChangeText={(value)=>{handleChange("pucPrct",value)}} isError={education.pucPrct}/>
          
          <Dropdown
              placeholder="Finished degree"
              items={[
                {label: 'Yes', value: 'Yes'},
                {label: 'No', value: 'No' },
              ]}
              onChangeItem={(value)=>{handleChange("fnshDegree",value.value)}}
              label ={ fnshDegree ? "finished degree" : false }
              value={fnshDegree}
              isError={education.fnshDegree}
          />

          {
            fnshDegree == "Yes" ?
            <>
             <Dropdown
                placeholder="Searching job"
                items={[
                  {label: 'Yes', value: 'Yes'},
                  {label: 'No', value: 'No' },
                ]}
                onChangeItem={(value)=>{handleChange("searchJob",value.value)}}
                label ={ searchJob ? "Searching job" : false }
                value={searchJob}
                isError={education.searchJob}
              />
              <TextInputA placeholder="Degree" value={degree} name="degree" onChangeText={(value)=>{handleChange("degree",value)}} isError={education.degree} />
              <TextInputA placeholder="Degree college" value={dCollege} name="dCollege" onChangeText={(value)=>{handleChange("dCollege",value)}} isError={education.dCollege} />
              <TextInputA placeholder="Degree %" keyboardType="number-pad" value={dPct} name="dPct" onChangeText={(value)=>{handleChange("dPct",value)}} isError={education.dPct}/>          
            </>
            : null
          }

        </View>

    </SafeAreaView>
  )
};

export default Education;