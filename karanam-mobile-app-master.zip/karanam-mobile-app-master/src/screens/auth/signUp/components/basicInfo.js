import React from 'react';
import { View, SafeAreaView } from 'react-native';
import TextInputA from '../../../../components/textInput/textInputA';
import Dropdown from '../../../../components/dropdown/dropdown';
import DatePick from '../../../../components/datepicker/datepicker';
import color from './../../../../styles/color';

const BasicInfo = ({ values : { first_name, last_name, gender, state, city, address, dob  }, handleChange, handleBlur, setFieldValue, errors, touched }) => {

  let basicInfo = {};

  return (
    <SafeAreaView style={{flex:1}}>

        <View style={{flex:1,backgroundColor:"white"}}>

          <TextInputA 
            placeholder="First name"
            value={first_name}
            onChangeText={handleChange("first_name")}
            onBlur={handleBlur("first_name")}
            isError={touched && touched.first_name && errors.first_name}
          />

          <TextInputA 
            placeholder="Last name"
            value={last_name}
            onChangeText={handleChange("last_name")}
            onBlur={handleBlur("last_name")}
            isError={touched && touched.last_name && errors.last_name}
          />

            <Dropdown
              placeholder="Select gender"
              items={[
                  { label: 'MALE', value: 'MALE' },
                  { label: 'FEMALE', value: 'FEMALE' },
              ]}
              onChangeItem={(value)=>{setFieldValue("gender",value)}}
              value={gender}
              isError={basicInfo.gender}
            />

            <Dropdown
              placeholder="Select state"
              items={[
                  {label: 'karnataka', value: 'karnataka'},
                  {label: 'tamil naadu', value: 'tamil naadu', },
                  {label: 'kerala', value: 'kerala', },
              ]}
              onChangeItem={(value)=>{setFieldValue("state",value)}}
              value={state}
              isError={basicInfo.state}
            />

            <Dropdown
              placeholder="Please select city"
              items={[
                {label: 'bangalore', value: 'bangalore'},
                {label: 'tumkur', value: 'tumkur', },
                {label: 'davanagere', value: 'davanagere', },
              ]}
              onChangeItem={(value)=>{setFieldValue("city",value)}}
              value={city}
              isError={basicInfo.city}
            />

          <TextInputA
            placeholder="Address"
            value={address}
            onChangeText={handleChange("address")}
            onBlur={handleBlur("address")}
            isError={touched && touched.address && errors.address}
            multiline={true} 
            numberOfLines={4}
          />

          <DatePick
            handleChange={(name,date)=>{ setFieldValue(name,date)}}
            name={"dob"}
            value={dob}
            label={"DOB"}
            maxDate={new Date()}
            placeHolder={"Date of birth"}
          />

        </View>

    </SafeAreaView>
  )
};

export default BasicInfo;