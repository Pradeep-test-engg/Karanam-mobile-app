import React, { useEffect } from 'react';
import { View, SafeAreaView } from 'react-native';
import text from '../../../../utils/text';
import TextInputA from '../../../../components/textInput/textInputA';
import Dropdown from '../../../../components/dropdown/dropdown';

const Credential = ({ data = {}, handleChange }) => {

  const {
    profession,
    usrName,
    phone,
    pswd,
    } = data;

    let credential = {};

  return (
    <SafeAreaView style={{flex:1}}>

        <View style={{flex:1,backgroundColor:"white"}}>

          <Dropdown
              placeholder="Please select you profession"
              items={[
                {label: 'student', value: 'student'},
                {label: 'work experience', value: 'work experience', },
                {label: 'domain expert', value: 'domain expert', },
            ]}
            onChangeItem={(value)=>{handleChange("profession",value.value)}}
            label ={ profession ? "profession" : false }
            value={profession}
            isError={credential.profession}
          />

          <TextInputA placeholder="User name" value={usrName} name="usrName" onChangeText={(value)=>{handleChange("usrName",value)}} isError={credential.usrName}  />
          <TextInputA placeholder="Phone number" keyboardType="number-pad" value={phone} name="phone" onChangeText={(value)=>{handleChange("phone",value)}} isError={credential.phone} />
          <TextInputA placeholder="Password" value={pswd} name="pswd" onChangeText={(value)=>{handleChange("pswd",value)}} isError={credential.pswd} />

        </View>

    </SafeAreaView>
  )
};

export default Credential;