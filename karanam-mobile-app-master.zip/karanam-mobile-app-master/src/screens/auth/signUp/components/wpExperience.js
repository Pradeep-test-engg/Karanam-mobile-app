import React, { useEffect } from 'react';
import { View, SafeAreaView } from 'react-native';
import text from '../../../../utils/text';
import TextInputA from '../../../../components/textInput/textInputA';
import Dropdown from '../../../../components/dropdown/dropdown';

const WPExperience = ({ data = {}, handleChange }) => {

  const {
    crntOrg,
    Dsgn,
    intrstInHighEdu,
    choose,
    intrstInDmnChng,
    dmnComments,
    intrstInOrgChng,
    orgComments,
    intrstSkills,
    } = data;

    let wpExperience ={}

  return (
    <SafeAreaView style={{flex:1}}>

        <View style={{flex:1,backgroundColor:"white"}}>

          <TextInputA placeholder="Current organization" value={crntOrg} name="crntOrg" onChangeText={(value)=>{handleChange("crntOrg",value)}} isError={wpExperience.crntOrg} />
          <TextInputA placeholder="Designation" value={Dsgn} name="Dsgn" onChangeText={(value)=>{handleChange("Dsgn",value)}} isError={wpExperience.Dsgn} />

          <Dropdown
                placeholder="Intrested in higher education"
                items={[
                  {label: 'Yes', value: 'Yes'},
                  {label: 'No', value: 'No', },
              ]}
              onChangeItem={(value)=>{handleChange("intrstInHighEdu",value.value)}}
              label ={ intrstInHighEdu ? "Intrested in higher education" : false }
              value={intrstInHighEdu}
              isError={wpExperience.intrstInHighEdu}
            />

          {
            intrstInHighEdu == "Yes" ?
            <TextInputA placeholder="which higher education" value={choose} name="choose" onChangeText={(value)=>{handleChange("choose",value)}} isError={wpExperience.choose} />
            : null
          }

          <Dropdown
                placeholder="Intrested in domain change"
                items={[
                  {label: 'Yes', value: 'Yes'},
                  {label: 'No', value: 'No', },
              ]}
              onChangeItem={(value)=>{handleChange("intrstInDmnChng",value.value)}}
              label ={ intrstInDmnChng ? "Intrested in domain change" : false }
              value={intrstInDmnChng}
              isError={wpExperience.intrstInDmnChng}
            />

          {
            intrstInDmnChng == "Yes" ?
            <TextInputA placeholder="which domain you are intrested in" value={dmnComments} name="dmnComments" onChangeText={(value)=>{handleChange("dmnComments",value)}} isError={wpExperience.dmnComments} />
            : null
          }

          <Dropdown
                placeholder="Intrested in organization change"
                items={[
                  {label: 'Yes', value: 'Yes'},
                  {label: 'No', value: 'No', },
              ]}
              onChangeItem={(value)=>{handleChange("intrstInOrgChng",value.value)}}
              label ={ intrstInOrgChng ? "Intrested in organization change" : false }
              value={intrstInOrgChng}
              isError={wpExperience.intrstInOrgChng}
            />

          {
            intrstInOrgChng == "Yes" ?
            <TextInputA placeholder="which organization you are intrested in" value={orgComments} name="orgComments" onChangeText={(value)=>{handleChange("orgComments",value)}} isError={wpExperience.orgComments} />
            : null
          }

          <TextInputA placeholder="Intrested skills" value={intrstSkills} name="intrstSkills" onChangeText={(value)=>{handleChange("intrstSkills",value)}} multiline={true} numberOfLines={4} isError={wpExperience.intrstSkills} />

        </View>

    </SafeAreaView>
  )
};

export default WPExperience;