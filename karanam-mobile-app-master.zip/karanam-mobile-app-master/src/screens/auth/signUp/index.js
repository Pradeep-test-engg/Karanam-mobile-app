import React, { useState } from 'react';
import SignUpPC from "./signUp";
import { studentLabels } from './utils/labels';
import { studntStepData, wrkExpStepData, dmnExprtStepData } from './utils/stepHandler.js';

const SignUp = () =>{

  const [ currentStep, setCurrentStep ] = useState(0);

  let FormComp = studntStepData[currentStep].stepComponent;
  
  let labels = studentLabels;

  const handleStepChange = async(type) =>{
    if(currentStep == 3){
      sendOtp()
    }
    if(type == "next" && currentStep != 3){
        setCurrentStep(currentStep+1)
    }
    else if(type == "prev" && currentStep != 0){
      setCurrentStep(currentStep-1)
    }
  }

    return(
        <SignUpPC 
            currentStep={currentStep}            
            handleStepChange={handleStepChange} 
            FormComp={FormComp}
            labels={labels}
        />
    )
}

export default SignUp;
