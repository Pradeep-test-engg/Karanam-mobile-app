import React, { useState, useEffect } from 'react';
import { SafeAreaView, ScrollView, View, TouchableOpacity, Image } from 'react-native';
import StatusBar from '../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../styles/index.js';
import Header from '../../components/header/header';
import TextComp from '../../components/text/text';
import { FlatList } from 'react-native-gesture-handler';
import { add_to_cart_thunk, get_all_wishlist_thunk, remove_cartwishlist_thunk } from './../../store/cart/cartThunk';
import { connect } from 'react-redux';

const Wishlist = (props) => {

    const {
        user_id,
        add_to_cart,
        wishlistItems,
        get_all_wishlist,
        remove_cartwishlist,
        } = props;

    useEffect(()=>{
        get_all_wishlist(user_id);
    },[]);

    const handle_remove_cart = async(course_id) =>{
        const data = {
            course_id:[course_id]
        }
        await remove_cartwishlist(user_id,data);
    }

    const handle_move_cart = async(course_id) =>{
        const data = {
            course_id:course_id
        }
        await add_to_cart(user_id,data);
    }

    const { data, loading } = wishlistItems;

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Wishlist"}
                    onLeftPress={()=>{props.navigation.goBack()}}
                    isRight={false}
                />

                <View style={{flex:1}}>

                    <View style={{marginHorizontal:16,marginTop:16,flexDirection:"row"}}>
                        <TextComp value={"Wishlist items"} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.xxbig}}/>
                    </View>

                    <View style={{marginHorizontal:10,marginTop:16}}>

                        <FlatList
                            data={data}
                            renderItem={(props)=>{
                                return(
                                    <WishlistItems {...props} handle_remove_cart={handle_remove_cart} handle_move_cart={handle_move_cart}/>
                                )
                            }}
                            ListEmptyComponent={
                                <View style={{alignItems:"center",justifyContent:"center",flex:1,marginTop:150}}>
                                    <TextComp value={"No courses in wishlist"} style={{textAlign:"left",fontSize:size.xxbig}}/>
                                </View>
                            }
                        />

                    </View>

                </View>
            </ScrollView>

        </SafeAreaView>
    );

};

const mapStateToProps = (state) =>{

    return{
        user_id:state.auth.user.user.id,
        wishlistItems:state.cart.wishlistItems
    };
}

const mapDispatchToProps = (dispatch) =>{

    return{
        get_all_wishlist:(user_id)=>{dispatch(get_all_wishlist_thunk(user_id))},
        add_to_cart:(user_id,data)=>{dispatch(add_to_cart_thunk(user_id,data,true))},
        remove_cartwishlist:(user_id,data)=>{dispatch(remove_cartwishlist_thunk(user_id,data,true))},
    };

}
  
export default connect(mapStateToProps,mapDispatchToProps)(Wishlist);

const WishlistItems = ({item,key,handle_remove_cart,handle_move_cart}) =>{

    const { Course:{ title, thumbnail, short_description, price, id } } = item;

    return(
        <View key={key} style={{backgroundColor:color.xxgray,marginBottom:12,padding:10,borderRadius:6}}>

            <View style={{flexDirection:"row"}}>

                <View style={{height:60,width:60}}>
                    <Image source={{uri:thumbnail}} style={{height:"100%"}} />
                </View>

                <View style={{flex:1,marginLeft:8}}>
                    <View>
                        <TextComp value={title} style={{fontSize:size.small,textAlign:"center"}} />
                    </View>
                    <View style={{flexDirection:"row",justifyContent:"space-around",alignItems:"center",flexWrap:"wrap",marginTop:6}}>
                        {/* <TextComp value={`${short_description}`} style={{fontSize:size.small,color:color.xgray}} /> */}
                        <TextComp value={`₹ ${price}.00`} style={{fontSize:size.small,color:color.black,fontFamily:font.bold}} />
                    </View>

                    {/* <View style={{flexDirection:"row",justifyContent:"center",alignItems:"center",flexWrap:"wrap",marginTop:6}}>
                        <Icon name="star" type="MaterialIcons" style={{color:color.orange,fontSize:size.medium}} />
                        <Icon name="star" type="MaterialIcons" style={{color:color.orange,fontSize:size.medium}} />
                        <Icon name="star" type="MaterialIcons" style={{color:color.orange,fontSize:size.medium}} />
                        <Icon name="star" type="MaterialIcons" style={{color:color.orange,fontSize:size.medium}} />
                        <Icon name="star-half" type="MaterialIcons" style={{color:color.orange,fontSize:size.medium}} />
                        <TextComp value={"4.5 (87)"} style={{marginLeft:5,textAlign:"left",fontFamily:font.bold,color:color.black,fontSize:size.small}}/>
                    </View> */}

                    <View style={{flexDirection:"row",alignItems:"center",justifyContent:"space-around",marginTop:6}}>
                        <TouchableOpacity onPress={()=>{handle_remove_cart(id)}}><Icon type="MaterialIcons" name="delete" color={color.black} size={size.big} /></TouchableOpacity>
                        <TouchableOpacity onPress={()=>{handle_move_cart(id)}}><Icon type="MaterialCommunityIcons" name="cart" color={color.black} size={size.big} /></TouchableOpacity>
                    </View>

                </View>

            </View>
        </View>
    )
}