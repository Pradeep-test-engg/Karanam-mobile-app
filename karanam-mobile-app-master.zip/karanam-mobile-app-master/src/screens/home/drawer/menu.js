import navigator from '../../../navigation/navigator';

export const Data1 = [
  {
    name: 'Search',
    icon: 'search',
    type: 'Feather',
    route: navigator.Search
  },
  {
    name: 'Cart',
    icon: 'shopping-cart',
    type: 'MaterialIcons',
    route: navigator.Cart  
  },
  {
    name: 'Wishlist',
    icon: 'heart',
    type: 'MaterialCommunityIcons',
    route: navigator.Wishlist  
  },
  {
    name: 'My Course',
    icon: 'results',
    type: 'Foundation',
    route: navigator.MyCourse  
  },
  {
    name: 'My Test',
    icon: 'indeterminate-check-box',
    type: 'MaterialIcons',
    route: navigator.MyTest  
  },
  {
    name: 'Profile',
    icon: 'user',
    type: 'Feather',
    route: navigator.MyProfile
  },
];