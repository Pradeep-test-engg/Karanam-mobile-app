import React, { Component } from 'react';
import { Image, FlatList, TouchableOpacity, ScrollView, View, Text } from 'react-native';
import { color, font, size, Icon } from '../../../styles/index.js';
import * as MENU from './menu'
import TextComp from '../../../components/text/text';

const HomeDrawer = (props) =>{

    return(
        <View style={{flex:1}}>
            <View style={{marginTop:30}}>
                <TextComp value={"Karnam LMS"} style={{fontSize:size.xbig,fontFamily:font.bold,textAlign:"left",left:20}} />
            </View>

            <View style={{marginTop:20}}>
                {
                    MENU.Data1.map((data) =>(
                        <TouchableOpacity style={{marginVertical:20,marginLeft:20,alignItems:"center",justifyContent:"flex-start",flexDirection:"row"}}
                            onPress={()=>{props.navigation.navigate(data.route)}}>
                            <Icon name={data.icon} type={data.type} style={{color:color.xblue,fontSize:size.xbig,marginRight:20}} />
                            <TextComp value={data.name} style={{fontSize:size.big}} />
                        </TouchableOpacity>
                    ))
                }
            </View>

        </View>
    )
}

export default HomeDrawer;