import React from 'react';
import { SafeAreaView, ScrollView, View, TouchableOpacity, Image, Text } from 'react-native';
import StatusBar from '../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../styles/index.js';
import Header from '../../components/header/header';
import TextComp from '../../components/text/text';
import Button from '../../components/button/button';
import { FlatList } from 'react-native-gesture-handler';
import navigator, { main_stack } from '../../navigation/navigator';
import MyCourseLatest from './mycourselatest/index';

const Home = (props) => {

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Home"}

                    onLeftPress={()=>{props.navigation.openDrawer()}}
                    leftIcon={{
                        type:"MaterialCommunityIcons",
                        name:"menu",
                        size:size.xxxbig
                    }}

                    rightIcon={{
                        type:"MaterialIcons",
                        name:"notifications",
                        size:size.xxxbig
                    }}
                />

                <View>
                    <TextComp value={"Hi, Nandeesh"} style={{textAlign:"left",marginHorizontal:14,marginTop:10,fontSize:size.xxxbig,fontFamily:font.bold}} />
                    <TextComp value={"looking for course suggestions ?"} style={{textAlign:"left",marginHorizontal:14,marginTop:10,fontSize:size.medium,color:color.xgray,fontFamily:font.bold}} />
                </View>

                <TouchableOpacity style={{backgroundColor:color.xxgray,marginHorizontal:14,marginVertical:20,borderRadius:6,flexDirection:"row",alignItems:"center",justifyContent:"space-between"}}
                    onPress={()=>{props.navigation.navigate(main_stack.search_screen)}}>
                    <TextComp value={"Search all courses"} style={{textAlign:"left",marginHorizontal:14,paddingVertical:16,fontSize:size.medium,color:color.xgray,fontFamily:font.bold}} />
                    <Icon name="search" type="FontAwesome" style={{fontSize:size.big,right:20}}  />
                </TouchableOpacity>

                <View style={{flexDirection:"row",justifyContent:"center",marginHorizontal:20}}>
                    {/* <TextComp value={"Take your test"} style={{marginHorizontal:4,fontSize:size.xbig,fontFamily:font.bold,left:10}} /> */}
                    <Button value="Take your test now" width="100%" buttonStyle={{paddingVertical:10,paddingHorizontal:80}} onPress={()=>{props.navigation.navigate(navigator.test)}}/>
                </View>

                <View style={{marginHorizontal:14,marginTop:20}}>
                    <View style={{flexDirection:"row"}}>
                        <View>
                            <TextComp value={"Suggested courses"} style={{textAlign:"left",fontSize:size.xbig,fontFamily:font.bold}} />
                            <TextComp value={"based on your test score"} style={{textAlign:"left",marginTop:7,fontSize:size.medium,color:color.xgray,fontFamily:font.bold}} />
                        </View>
                        <TouchableOpacity style={{alignItems:"center",justifyContent:"flex-end",flex:1,flexDirection:"row"}}>
                            <TextComp value={"View all"} style={{textAlign:"left",fontSize:size.big,fontFamily:font.bold,right:4}} />
                            <Icon name="angle-double-right" type="FontAwesome5" style={{fontSize:size.medium}}  />
                        </TouchableOpacity>
                    </View>
                    <View style={{marginTop:16}}>
                        <FlatList
                            showsHorizontalScrollIndicator={false}
                            data={[1,2,3,4,5]}
                            renderItem={({})=>(
                                <Course2 {...props}/>
                            )}
                            horizontal
                        />
                    </View>
                </View>

                <View style={{marginHorizontal:14,marginTop:20,backgroundColor:"white"}}>
                    <MyCourseLatest />
                </View>

            </ScrollView>
        </SafeAreaView>
    );

};

export default Home;

const Course2 = ({navigation}) =>{
    return(
        <TouchableOpacity style={{width:180,marginRight:20,height:180,borderRadius:6}} onPress={()=>navigation.navigate(navigator.CourseBuy)}>
            <View style={{backgroundColor:color.xxgray,height:120,width:180,borderRadius:6}}>
                <Image source={{uri:image1}} style={{height:"100%",width:"100%",borderRadius:2}} />
            </View>
            <View style={{alignItems:"center",justifyContent:"center",marginTop:4}}>
                <TextComp value={"Build Responsive website using HTML5, CSS3 and Javascript"} style={{textAlign:"center",fontSize:size.small}} />
            </View>
        </TouchableOpacity>
    )
}

let image1 = "https://cdn6.f-cdn.com/contestentries/1122631/25928748/59a930ffbbe4c_thumb900.jpg";
