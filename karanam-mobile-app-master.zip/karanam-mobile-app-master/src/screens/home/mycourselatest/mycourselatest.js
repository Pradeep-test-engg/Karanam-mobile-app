import React from 'react';
import { FlatList, TouchableOpacity, View,Image } from 'react-native';
import { color, font, size, Icon } from '../../../styles/index.js';
import navigate from './../../../utils/navigate';
import TextComp from './../../../components/text/text';

export default ({ data }) => {

    return (
        <>
            <View style={{flexDirection:"row",backgroundColor:"white"}}>
                <View>
                    <TextComp value={"My courses"} style={{textAlign:"left",fontSize:size.xbig,fontFamily:font.bold}} />
                    <TextComp value={"resume your courses"} style={{textAlign:"left",marginTop:7,fontSize:size.medium,color:color.xgray,fontFamily:font.bold}} />
                </View>
                <TouchableOpacity style={{alignItems:"center",justifyContent:"flex-end",flex:1,flexDirection:"row"}}>
                    <TextComp value={"View all"} style={{textAlign:"left",fontSize:size.big,fontFamily:font.bold,right:4}} />
                    <Icon name="angle-double-right" type="FontAwesome5" style={{fontSize:size.medium}}  />
                </TouchableOpacity>
            </View>

            <View style={{marginTop:16,backgroundColor:"white"}}>
                <FlatList
                    showsHorizontalScrollIndicator={false}
                    data={data}
                    renderItem={({item})=>(
                        <Course1 item={item}/>
                    )}
                    horizontal
                />
            </View>
        </>
    );
};

const Course1 = ({item}) =>{

    console.log(item);

    const { Course : { thumbnail, title } } = item;

    return(
        <TouchableOpacity style={{width:180,marginRight:20,height:180,borderRadius:6}}
        >
            <View style={{backgroundColor:color.xxgray,height:120,width:180,borderRadius:6}}>
                <Image source={{uri:thumbnail}} style={{height:"100%",width:"100%",borderRadius:2}} />
            </View>
            <View style={{alignItems:"center",justifyContent:"center",marginTop:4}}>
                <TextComp value={title} style={{textAlign:"center",fontSize:size.small}} />
            </View>
        </TouchableOpacity>
    )
}
