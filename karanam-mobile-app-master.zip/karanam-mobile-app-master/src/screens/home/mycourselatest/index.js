import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import MyCourseLatestPS from './mycourselatest';
import courseSelector from '../../../store/course/selector';
import courseThunk from '../../../store/course/thunk';

const MyCourseLatest = () => {

    const myCourse = useSelector(courseSelector.myCourse);

    const [ status, setStatus ] = useState({
        loading:false,
        error:null,
    });

    const dispatch = useDispatch();

    useEffect(()=>{
        const test = async() =>{
            try {
                dispatch(courseThunk.getMyLatestCourse({data:{user_id:41,page:1,limit:10},handler:setStatus}));

            } catch (error) {
                
            }
        }
        test()
    },[])

    // console.log("status",status);

    // const onSubmit = (value) =>{
    //     const data = {basic:value};
    //     (JSON.stringify(basic_info) !== JSON.stringify(value)) && dispatch(authThunk.updateProfile({
    //         data:data,
    //         handler:setStatus,
    //         type:"basic",
    //     }));
    // };

    return (
        <MyCourseLatestPS data={myCourse} />
    );

};

export default MyCourseLatest;