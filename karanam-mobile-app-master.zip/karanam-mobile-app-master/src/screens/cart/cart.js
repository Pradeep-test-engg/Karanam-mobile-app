import React, { useState, useEffect } from 'react';
import { SafeAreaView, ScrollView, View, TouchableOpacity, Image } from 'react-native';
import StatusBar from '../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../styles/index.js';
import Header from '../../components/header/header';
import TextComp from '../../components/text/text';
import { FlatList } from 'react-native-gesture-handler';
import Button from '../../components/button/button';
import navigator from '../../navigation/navigator';
import { get_all_cart_thunk, remove_cartwishlist_thunk, add_to_wishlist_thunk } from './../../store/cart/cartThunk';
import { connect } from 'react-redux';

const Cart = (props) => {

    const { 
        user_id,
        cartItems,
        remove_cartwishlist,
        add_to_wishlist,
        } = props;

    useEffect(()=>{
        props.getAllCart(user_id);
    },[]);

    const { data, loading } = cartItems;

    const total = calcTotal(data);

    const handle_remove_cart = async(course_id) =>{
        const data = {
            course_id:[course_id]
        }
        await remove_cartwishlist(user_id,data);
    }

    const handle_move_wishlist = async(course_id) =>{
        const data = {
            course_id:course_id
        }
        await add_to_wishlist(user_id,data);
    }

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Cart"}
                    onLeftPress={()=>{props.navigation.goBack()}}
                    isRight={false}
                />

                <View style={{flex:1}}>

                    <View style={{marginHorizontal:16,marginTop:16,flexDirection:"row"}}>
                        <View style={{flex:1,justifyContent:"center"}}>
                            <TextComp value={"Cart items"} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.xxbig}}/>
                        </View>
                        <View>
                            <TextComp value={`Total = ₹${total}`} style={{textAlign:"right",fontFamily:font.bold,fontSize:size.xxbig}}/>
                        </View>
                    </View>

                    {
                        total > 0 &&  
                        <View style={{flexDirection:"row",marginHorizontal:10,justifyContent:"center",marginVertical:10}}>
                            <Button onPress={()=>{props.navigation.navigate(navigator.Checkout)}} value={"Proced to checkout"} width="80%" buttonStyle={{backgroundColor:color.xblue}} textStyle={{}} />
                        </View>
                    }

                    <View style={{marginHorizontal:10}}>

                        <FlatList
                            data={data}
                            renderItem={(props)=>{
                                return(
                                    <CartItems {...props} handle_remove_cart={handle_remove_cart} handle_move_wishlist={handle_move_wishlist}/>
                                )
                            }}
                            ListEmptyComponent={
                                <View style={{alignItems:"center",justifyContent:"center",flex:1,marginTop:150}}>
                                    <TextComp value={"No courses in cart"} style={{textAlign:"left",fontSize:size.xxbig}}/>
                                </View>
                            }
                        />

                    </View>

                </View>
            </ScrollView>

        </SafeAreaView>
    );

};

const mapStateToProps = (state) =>{
    return{
        user_id:state.auth.user.user.id,
        cartItems:state.cart.cartItems
    };
}

const mapDispatchToProps = (dispatch) =>{

    return{
        getAllCart:(user_id)=>{dispatch(get_all_cart_thunk(user_id))},
        remove_cartwishlist:(user_id,data)=>{dispatch(remove_cartwishlist_thunk(user_id,data))},
        add_to_wishlist:(user_id,data)=>{dispatch(add_to_wishlist_thunk(user_id,data,true))},
    };
}
  
export default connect(mapStateToProps,mapDispatchToProps)(Cart);

const CartItems = ({item,key,handle_remove_cart,handle_move_wishlist}) =>{

    const { Course:{ title, thumbnail, short_description, price, id } } = item;

    return(
        <View key={key} style={{backgroundColor:color.xxgray,marginBottom:12,padding:10,borderRadius:6}}>

            <View style={{flexDirection:"row"}}>

                <View style={{height:60,width:60}}>
                    <Image source={{uri:thumbnail}} style={{height:"100%"}} />
                </View>

                <View style={{flex:1,marginLeft:8}}>
                    <View>
                        <TextComp value={title} style={{fontSize:size.small,textAlign:"center"}} />
                    </View>
                    <View style={{flexDirection:"row",justifyContent:"space-around",alignItems:"center",flexWrap:"wrap",marginTop:6}}>
                        <TextComp value={short_description} style={{fontSize:size.small,color:color.xgray}} />
                        <TextComp value={`₹ ${price}.00`} style={{fontSize:size.small,color:color.black,fontFamily:font.bold}} />
                    </View>

                    <View style={{flexDirection:"row",alignItems:"center",justifyContent:"space-around",marginTop:6}}>
                        <TouchableOpacity onPress={()=>{handle_remove_cart(id)}}><Icon type="MaterialIcons" name="delete" color={color.black} size={size.big} /></TouchableOpacity>
                        <TouchableOpacity onPress={()=>{handle_move_wishlist(id)}}><Icon type="MaterialCommunityIcons" name="heart-outline" color={color.black} size={size.big} /></TouchableOpacity>
                    </View>

                </View>

            </View>
        </View>
    )
}

const calcTotal = (data) => {
    return data.reduce((preVal,curVal)=>(preVal + parseInt(curVal.Course.price)),0);
}