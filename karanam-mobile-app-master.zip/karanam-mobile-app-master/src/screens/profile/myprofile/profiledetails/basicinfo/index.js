import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import BasicInfoPS from './basicinfo';
import authSelector from '../../../../../store/auth/selector';
import authThunk from '../../../../../store/auth/thunk';

const BasicInfo = () => {

    const basic_info = useSelector(authSelector.basicInfo);

    const [ status, setStatus ] = useState({
        loading:false,
        error:null,
    });

    const dispatch = useDispatch();

    const onSubmit = (value) =>{
        const data = {basic:value};
        (JSON.stringify(basic_info) !== JSON.stringify(value)) && dispatch(authThunk.updateProfile({
            data:data,
            handler:setStatus,
            type:"basic",
        }));
    };

    return (
        <BasicInfoPS data={basic_info} status={status} onSubmit={onSubmit} />
    );

};

export default BasicInfo;