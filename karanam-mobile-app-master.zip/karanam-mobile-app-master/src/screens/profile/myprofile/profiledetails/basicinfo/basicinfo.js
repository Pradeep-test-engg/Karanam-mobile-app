import React from 'react';
import { SafeAreaView, ScrollView, View } from 'react-native';
import { Formik } from 'formik';
import StatusBar from '../../../../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../../../../styles/index.js';
import Header from '../../../../../components/header/header';
import navigate from './../../../../../utils/navigate';
import TextInputA from './../../../../../components/textInput/textInputA';
import Dropdown from './../../../../../components/dropdown/dropdown';
import DatePick from './../../../../../components/datepicker/datepicker';
import Button from '../../../../../components/button/button';
import TextComp from './../../../../../components/text/text';
import schema from './../../../../../utils/validationSchema';

export default ({ data, onSubmit, status: { loading, error } }) => {

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Basic info"}
                    onLeftPress={()=>{navigate({isBack:true})}}
                />

                <Formik
                    initialValues={data}
                    enableReinitialize={true}
                    onSubmit={onSubmit}
                    validationSchema={schema.basic_info}
                >
                {({ handleChange, 
                    handleBlur, 
                    handleSubmit, 
                    setFieldValue,
                    values, 
                    errors,
                    touched,
                    isValid,
                    ...props
                    }) => {
                    return(
                    <>
                    <View style={{flex:1,marginHorizontal:20}}>

                        <View style={{marginVertical:20,alignItems:"flex-start",justifyContent:"center"}}>
                            <TextComp value={"Basic details"} style={{fontSize:size.xxbig}}/>
                            <TextComp value={"Edit basic details"} style={{fontSize:size.small,marginTop:6}}/>
                        </View>

                        <TextInputA 
                            placeholder="First name"
                            name="firstname"
                            value={values.firstname}
                            onChangeText={handleChange("firstname")}
                            onBlur={handleBlur("firstname")}
                            isError={touched && touched.firstname && errors.firstname}
                        />

                        <TextInputA 
                            placeholder="Last name"
                            name="lastname"
                            value={values.lastname} 
                            onChangeText={handleChange("lastname")}
                            onBlur={handleBlur("lastname")}
                            isError={touched && touched.lastname && errors.lastname}
                        />

                        <Dropdown
                            placeholder="Please select gender"
                            items={[
                                {label: 'male', value: 'male'},
                                {label: 'female', value: 'female', },
                            ]}
                            onChangeItem={(value)=>{setFieldValue("gender",value.value)}}
                            label ={ values.gender ? "gender" : false }
                            value={values.gender}
                            isError={touched && touched.gender && errors.gender}
                        />

                        <Dropdown
                            placeholder="Please select state"
                            items={[
                                {label: 'karnataka', value: 'karnataka'},
                                {label: 'tamil naadu', value: 'tamil naadu', },
                                {label: 'kerala', value: 'kerala', },
                            ]}
                            onChangeItem={(value)=>{setFieldValue("state",value.value)}}
                            label ={ values.state ? "state" : false }
                            value={values.state}
                            isError={touched && touched.state && errors.state}
                        />

                        <Dropdown
                            placeholder="Please select city"
                            items={[
                                {label: 'bangalore', value: 'bangalore'},
                                {label: 'tumkur', value: 'tumkur', },
                                {label: 'davanagere', value: 'davanagere', },
                            ]}
                            onChangeItem={(value)=>{setFieldValue("city",value.value)}}
                            label ={ values.city ? "city" : false }
                            value={values.city}
                            isError={touched && touched.city && errors.city}
                        />

                        <TextInputA
                            placeholder="Address"
                            name="address"
                            multiline={true}
                            numberOfLines={4}
                            value={values.address}
                            onChangeText={handleChange("address")}
                            onBlur={handleBlur("address")}
                            isError={touched && touched.address && errors.address}
                        />

                        <DatePick
                            handleChange={(name,date)=>{ setFieldValue(name,date)}}
                            name={"dob"}
                            value={values.dob}
                            label={"DOB"}
                            placeHolder={"Date of birth"}
                        />

                    </View>

                    <View style={{marginHorizontal:20,marginVertical:30,backgroundColor:"blue",borderRadius:6}}>
                        <Button
                            value={"Update"}
                            onPress={()=>{handleSubmit()}}
                            buttonStyle={{paddingVertical:10}}
                            textStyle={{color:color.white}}
                            loading={loading}
                            disabled={!isValid}
                        />
                    </View>
                    </>
                  )}}
            </Formik>

            </ScrollView>

        </SafeAreaView>
    );

};
