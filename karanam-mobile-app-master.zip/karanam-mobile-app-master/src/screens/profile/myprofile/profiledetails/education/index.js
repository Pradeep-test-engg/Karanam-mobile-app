import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import EducationPS from './education';
import authSelector from '../../../../../store/auth/selector';
import authThunk from '../../../../../store/auth/thunk';

const Education = () => {

    const education = useSelector(authSelector.education);

    const [ status, setStatus ] = useState({
        loading:false,
        error:null,
    });

    const dispatch = useDispatch();

    const onSubmit = (value) =>{
        const data = {education:value};
        (JSON.stringify(education) !== JSON.stringify(value)) && dispatch(authThunk.updateProfile({
            data:data,
            handler:setStatus,
            type:"education",
        }));
    };

    return (
        <EducationPS data={education} status={status} onSubmit={onSubmit} />
    );

};

export default Education;