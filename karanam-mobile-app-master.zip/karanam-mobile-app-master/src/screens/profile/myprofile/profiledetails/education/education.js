import React from 'react';
import { SafeAreaView, ScrollView, View } from 'react-native';
import { Formik } from 'formik';
import StatusBar from '../../../../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../../../../styles/index.js';
import Header from '../../../../../components/header/header';
import navigate from './../../../../../utils/navigate';
import TextInputA from './../../../../../components/textInput/textInputA';
import Dropdown from './../../../../../components/dropdown/dropdown';
import Button from '../../../../../components/button/button';
import TextComp from './../../../../../components/text/text';
import schema from './../../../../../utils/validationSchema';

export default ({ data, onSubmit, status: { loading, error } }) => {

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Education"}
                    onLeftPress={()=>{navigate({isBack:true})}}
                    />

                <Formik
                    initialValues={data}
                    enableReinitialize={true}
                    onSubmit={onSubmit}
                    // validationSchema={schema.basic_info}
                >
                {({ handleChange, 
                    handleBlur, 
                    handleSubmit, 
                    setFieldValue,
                    values, 
                    errors,
                    touched,
                    isValid,
                    ...props
                    }) => {
                    return(
                    <>
                        <View style={{flex:1,marginHorizontal:20}}>

                            <View style={{marginVertical:20,alignItems:"flex-start",justifyContent:"center"}}>
                                <TextComp value={"Education"} style={{fontSize:size.xxbig}}/>
                                <TextComp value={"Edit education details"} style={{fontSize:size.small,marginTop:6}}/>
                            </View>

                            <TextInputA 
                                placeholder="SSLC school"
                                value={values.school_name}
                                onChangeText={handleChange("school_name")}
                                onBlur={handleBlur("school_name")}
                                isError={touched && touched.school_name && errors.school_name}
                            />

                            <TextInputA 
                                placeholder="SSLC %" 
                                keyboardType="number-pad" 
                                value={values.sslc_percentage}
                                onChangeText={handleChange("sslc_percentage")}
                                onBlur={handleBlur("sslc_percentage")}
                                isError={touched && touched.sslc_percentage && errors.sslc_percentage}
                            />
                            
                            <TextInputA 
                                placeholder="PUC college"
                                value={values.college_name}
                                onChangeText={handleChange("college_name")}
                                onBlur={handleBlur("college_name")}
                                isError={touched && touched.college_name && errors.college_name}
                            />
                            
                            <TextInputA 
                                placeholder="PUC %" 
                                keyboardType="number-pad" 
                                value={values.college_percentage}
                                onChangeText={handleChange("college_percentage")}
                                onBlur={handleBlur("college_percentage")}
                                isError={touched && touched.college_percentage && errors.college_percentage}
                            />
                            
                            <Dropdown
                                placeholder="Finished degree"
                                items={[
                                    {label: 'Yes', value: true},
                                    {label: 'No', value: false },
                                ]}
                                onChangeItem={(value)=>{setFieldValue("degree_completed",value.value)}}
                                label ={ values.degree_completed.toString() == "true" || "false" ? "Finished degree" : false }
                                value={values.degree_completed}
                                isError={touched && touched.degree_completed && errors.degree_completed}
                            />

                            {
                                values.degree_completed &&
                                <>
                                <Dropdown
                                    placeholder="Searching job"
                                    items={[
                                        {label: 'Yes', value: true},
                                        {label: 'No', value: false },
                                    ]}
                                    onChangeItem={(value)=>{setFieldValue("search_job",value.value)}}
                                    label ={ values.search_job.toString() == "true" || "false" ? "Searching job" : false }
                                    value={values.search_job}
                                    isError={touched && touched.search_job && errors.search_job}
                                />

                                <TextInputA 
                                    placeholder="Degree" 
                                    value={values.degree_type}
                                    onChangeText={handleChange("degree_type")}
                                    onBlur={handleBlur("degree_type")}
                                    isError={touched && touched.degree_type && errors.degree_type}
                                />
                                
                                <TextInputA 
                                    placeholder="Degree college"
                                    value={values.degree_college}
                                    onChangeText={handleChange("degree_college")}
                                    onBlur={handleBlur("degree_college")}
                                    isError={touched && touched.degree_college && errors.degree_college}
                                />
                                
                                <TextInputA 
                                    placeholder="Degree %" 
                                    keyboardType="number-pad" 
                                    value={values.degree_percentage}
                                    onChangeText={handleChange("degree_percentage")}
                                    onBlur={handleBlur("degree_percentage")}
                                    isError={touched && touched.degree_percentage && errors.degree_percentage}
                                />          
                                </>
                            }

                        </View>

                        <View style={{marginHorizontal:20,marginVertical:30,backgroundColor:"blue",borderRadius:6}}>
                            <Button
                                value={"Update"}
                                onPress={()=>{handleSubmit()}}
                                buttonStyle={{paddingVertical:10}}
                                textStyle={{color:color.white}}
                                loading={loading}
                                disabled={!isValid}
                            />
                        </View>
                    </>
                  )}}
            </Formik>

            </ScrollView>

        </SafeAreaView>
    );

};
