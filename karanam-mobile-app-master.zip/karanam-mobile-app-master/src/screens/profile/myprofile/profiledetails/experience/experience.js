import React from 'react';
import { SafeAreaView, ScrollView, View } from 'react-native';
import StatusBar from '../../../../../components/statusbar/statusbar';
import { Formik } from 'formik';
import { color, font, size, Icon } from '../../../../../styles/index.js';
import Header from '../../../../../components/header/header';
import navigate from './../../../../../utils/navigate';
import TextInputA from './../../../../../components/textInput/textInputA';
import Dropdown from './../../../../../components/dropdown/dropdown';
import DatePick from './../../../../../components/datepicker/datepicker';
import Button from '../../../../../components/button/button';
import TextComp from './../../../../../components/text/text';
import schema from './../../../../../utils/validationSchema';

export default ({ data, onSubmit, status: { loading, error } }) => {

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Experience"}
                    onLeftPress={()=>{navigate({isBack:true})}}
                    />

                <Formik
                    initialValues={data}
                    enableReinitialize={true}
                    onSubmit={onSubmit}
                    // validationSchema={schema.basic_info}
                >
                {({ handleChange, 
                    handleBlur, 
                    handleSubmit, 
                    setFieldValue,
                    values, 
                    errors,
                    touched,
                    isValid,
                    ...props
                    }) => {
                    return(
                    <>
                        <View style={{flex:1,marginHorizontal:20}}>

                            <View style={{marginVertical:20,alignItems:"flex-start",justifyContent:"center"}}>
                                <TextComp value={"Experience"} style={{fontSize:size.xxbig}}/>
                                <TextComp value={"Edit experience details"} style={{fontSize:size.small,marginTop:6}}/>
                            </View>

                            <TextInputA 
                                placeholder="Current organization"
                                name="crntOrg"
                                value={values.crntOrg}
                                onChangeText={handleChange("crntOrg")}
                                onBlur={handleBlur("crntOrg")}
                                isError={touched && touched.crntOrg && errors.crntOrg}
                            />

                            <TextInputA 
                                placeholder="Designation"
                                name="designation"
                                value={values.designation}
                                onChangeText={handleChange("designation")}
                                onBlur={handleBlur("designation")}
                                isError={touched && touched.designation && errors.designation}
                            />

                            <Dropdown
                                placeholder="Intrested in higher education"
                                items={[
                                    {label: 'Yes', value: true},
                                    {label: 'No', value: false },
                                ]}
                                onChangeItem={(value)=>{setFieldValue("i_higher_edu",value.value)}}
                                label ={ values.i_higher_edu.toString() == "true" || "false" ? "Intrested in higher education" : false }
                                value={values.i_higher_edu}
                                isError={touched && touched.i_higher_edu && errors.i_higher_edu}
                            />

                            {
                                values.i_higher_edu &&
                                <TextInputA 
                                    placeholder="which higher education"
                                    name="choose_high_degree"
                                    value={values.choose_high_degree}
                                    onChangeText={handleChange("choose_high_degree")}
                                    onBlur={handleBlur("choose_high_degree")}
                                    isError={touched && touched.choose_high_degree && errors.choose_high_degree}
                                />
                            }

                            <Dropdown
                                placeholder="Intrested in domain change"
                                items={[
                                    {label: 'Yes', value: true},
                                    {label: 'No', value: false },
                                ]}
                                onChangeItem={(value)=>{setFieldValue("i_domain_change",value.value)}}
                                label ={ values.i_domain_change.toString() == "true" || "false" ? "Intrested in domain change" : false }
                                value={values.i_domain_change}
                                isError={touched && touched.i_domain_change && errors.i_domain_change}
                            />

                            {
                                values.i_domain_change &&
                                <TextInputA 
                                    placeholder="which domain you are intrested in"
                                    name="which domain you are intrested in"
                                    value={values.d_change_comments}
                                    onChangeText={handleChange("d_change_comments")}
                                    onBlur={handleBlur("d_change_comments")}
                                    isError={touched && touched.d_change_comments && errors.d_change_comments}
                                />
                            }

                            <Dropdown
                                placeholder="Intrested in organization change"
                                items={[
                                    {label: 'Yes', value: true},
                                    {label: 'No', value: false },
                                ]}
                                onChangeItem={(value)=>{setFieldValue("i_org_change",value.value)}}
                                label ={ values.i_org_change.toString() == "true" || "false" ? "Intrested in organization change" : false }
                                value={values.i_org_change}
                                isError={touched && touched.i_org_change && errors.i_org_change}
                            />

                            {
                                values.i_org_change &&
                                <TextInputA 
                                    placeholder="which organization you are intrested in"
                                    name="which organization you are intrested in"
                                    value={values.o_change_comments}
                                    onChangeText={handleChange("o_change_comments")}
                                    onBlur={handleBlur("o_change_comments")}
                                    isError={touched && touched.o_change_comments && errors.o_change_comments}
                                />
                            }

                                <TextInputA 
                                    placeholder="Intrested skills"
                                    name="Intrested skills"
                                    value={values.skill_set}
                                    onChangeText={handleChange("skill_set")}
                                    onBlur={handleBlur("skill_set")}
                                    isError={touched && touched.skill_set && errors.skill_set}
                                />

                        </View>

                        <View style={{marginHorizontal:20,marginVertical:30,backgroundColor:"blue",borderRadius:6}}>
                            <Button
                                value={"Update"}
                                onPress={()=>{handleSubmit()}}
                                buttonStyle={{paddingVertical:10}}
                                textStyle={{color:color.white}}
                                loading={loading}
                                disabled={!isValid}
                            />
                        </View>
                    </>
                  )}}
            </Formik>

            </ScrollView>

        </SafeAreaView>
    );

};
