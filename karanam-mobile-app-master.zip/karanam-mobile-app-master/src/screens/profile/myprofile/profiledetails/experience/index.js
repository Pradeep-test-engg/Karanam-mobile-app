import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import ExperiencePS from './experience';
import authSelector from '../../../../../store/auth/selector';
import authThunk from '../../../../../store/auth/thunk';

const Experience = () => {

    const experience = useSelector(authSelector.experience);

    const [ status, setStatus ] = useState({
        loading:false,
        error:null,
    });

    const dispatch = useDispatch();

    const onSubmit = (value) =>{
        const data = {experience:value};
        (JSON.stringify(experience) !== JSON.stringify(value)) && dispatch(authThunk.updateProfile({
            data:data,
            handler:setStatus,
            type:"experience",
        }));
    };

    return (
        <ExperiencePS data={experience} status={status} onSubmit={onSubmit} />
    );

};

export default Experience;