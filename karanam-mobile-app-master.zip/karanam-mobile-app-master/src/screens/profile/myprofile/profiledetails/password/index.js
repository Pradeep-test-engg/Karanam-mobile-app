import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import PasswordPS from './password';
import authService from '../../../../../store/auth/service';
import authSelector from '../../../../../store/auth/selector';

const Password = () => {

    const [ status, setStatus ] = useState({
        loading:false,
        error:null,
        success:null,
    });

    const userId = useSelector(authSelector.useId);

    const initialValues = { password: "", new_password: "", confirm_password: "" }

    const onSubmit = async(value) =>{
        try {
            setStatus((prevState) => {
                prevState.loading = true;
                prevState.error = null;
                prevState.success = null;
                return {...prevState};
            });
            let result = await authService.updateProfile(userId,{credential:value});
            setStatus((prevState) => {
                prevState.loading = false;
                prevState.success = result.msg ? result.msg : null;
                return {...prevState};
            });
        } catch (error) {
            setStatus((prevState) => {
                prevState.loading = false;
                prevState.error = error && error.msg ? error.msg : error;
                return {...prevState};
            });
        }
    };

    return (
        <PasswordPS status={status} initialValues={initialValues} onSubmit={onSubmit} />
    );

};

export default Password;