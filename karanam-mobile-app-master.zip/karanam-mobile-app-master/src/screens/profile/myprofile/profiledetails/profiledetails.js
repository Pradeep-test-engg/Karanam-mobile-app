import React from 'react';
import { SafeAreaView, ScrollView, View } from 'react-native';
import StatusBar from '../../../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../../../styles/index.js';
import Header from '../../../../components/header/header';
import TextComp from '../../../../components/text/text';
import { profile_stack } from './../../../../navigation/navigator';
import navigate from './../../../../utils/navigate';
import ItemCard from './../../../../components/cards/itemcard';

export default (props) => {

    const {

    } = props;

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Account details"}
                    onLeftPress={()=>{navigate({isBack:true})}}
                />

                <View style={{flex:1}}>

                    <View style={{flex:0.3,marginLeft:10,alignItems:"flex-start",justifyContent:"center"}}>
                        <TextComp value={"Your Account"} style={{fontSize:size.xxbig}}/>
                        <TextComp value={"Edit your account details"} style={{fontSize:size.small,marginTop:6}}/>
                    </View>

                    <View style={{flex:1}}>

                        <Card text={"Basic info"} path={profile_stack.basic_info} />

                        <Card text={"Credentials"} path={profile_stack.credential} />

                        <Card text={"Id details"} path={profile_stack.id_details} />

                        <Card text={"Education"} path={profile_stack.education} />

                        <Card text={"Experience"} path={profile_stack.experience} />

                        <Card text={"Change password"} path={profile_stack.password} />

                    </View>

                </View>
            </ScrollView>

        </SafeAreaView>
    );

};

const Card = ({text, path}) => <ItemCard text={text} textStyle={{fontSize:size.medium}} itemStyle={{paddingVertical:8,marginHorizontal:10,marginBottom:12}} onPress={()=>{navigate({path:path})}} />