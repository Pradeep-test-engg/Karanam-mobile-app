import React from 'react';
import ProfileDetail from './profiledetails';

const ProfileDetails = (props) => {
    
    return (
        <ProfileDetail {...props} />
    );

};

export default ProfileDetails;