import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import CredentialPS from './credential';
import authSelector from '../../../../../store/auth/selector';
import authThunk from '../../../../../store/auth/thunk';

const Credential = () => {

    const credential = useSelector(authSelector.credential);

    const [ status, setStatus ] = useState({
        loading:false,
        error:null,
    });

    const dispatch = useDispatch();

    const onSubmit = (value) =>{
        const data = {credential:value};
        (JSON.stringify(credential) !== JSON.stringify(value)) && dispatch(authThunk.updateProfile({
            data:data,
            handler:setStatus,
            type:"credential",
        }));
    };

    return (
        <CredentialPS data={credential} status={status} onSubmit={onSubmit} />
    );

};

export default Credential;