import React from 'react';
import { SafeAreaView, ScrollView, View } from 'react-native';
import { Formik } from 'formik';
import StatusBar from '../../../../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../../../../styles/index.js';
import Header from '../../../../../components/header/header';
import navigate from './../../../../../utils/navigate';
import TextInputA from './../../../../../components/textInput/textInputA';
import Dropdown from './../../../../../components/dropdown/dropdown';
import Button from '../../../../../components/button/button';
import TextComp from './../../../../../components/text/text';
import schema from './../../../../../utils/validationSchema';

export default (props) => {

    const {
        profession,
        email,
        phone,
        credential = {},
        handleChange,
        data, onSubmit, status: { loading, error },
    } = props;

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Credentials"}
                    onLeftPress={()=>{navigate({isBack:true})}}
                    />

                <Formik
                    initialValues={data}
                    enableReinitialize={true}
                    onSubmit={onSubmit}
                    // validationSchema={schema.basic_info}
                >
                {({ handleChange, 
                    handleBlur, 
                    handleSubmit, 
                    setFieldValue,
                    values, 
                    errors,
                    touched,
                    isValid,
                    ...props
                    }) => {
                    return(
                    <>
                        <View style={{flex:1,marginHorizontal:20}}>

                            <View style={{marginVertical:20,alignItems:"flex-start",justifyContent:"center"}}>
                                <TextComp value={"Credentials"} style={{fontSize:size.xxbig}}/>
                                <TextComp value={"Edit credentials details"} style={{fontSize:size.small,marginTop:6}}/>
                            </View>

                            <Dropdown
                                placeholder="Please select you profession"
                                items={[
                                    {label: 'student', value: 'student'},
                                    {label: 'work experience', value: 'work experience', },
                                    {label: 'domain expert', value: 'domain expert', },
                                ]}
                                onChangeItem={(value)=>{handleChange("profession",value.value)}}
                                label ={ profession ? "profession" : false }
                                value={"student"}
                                isError={credential.profession}
                            />

                            <TextInputA
                                placeholder="Email"
                                name="Email"
                                keyboardType="email-address"
                                value={values.email}
                                onChangeText={handleChange("email")}
                                onBlur={handleBlur("email")}
                                isError={touched && touched.email && errors.email}
                                editable={false}
                            />

                            <TextInputA
                                placeholder="Phone number"
                                name="Phone number"
                                keyboardType="number-pad" 
                                value={values.phone_no}
                                onChangeText={handleChange("phone_no")}
                                onBlur={handleBlur("phone_no")}
                                isError={touched && touched.phone_no && errors.phone_no}
                                editable={false}
                            />

                        </View>

                        <View style={{marginHorizontal:20,marginVertical:30,backgroundColor:"blue",borderRadius:6}}>
                            <Button
                                value={"Update"}
                                onPress={()=>{handleSubmit()}}
                                buttonStyle={{paddingVertical:10}}
                                textStyle={{color:color.white}}
                                loading={loading}
                                disabled={!isValid}
                            />
                        </View>
                    </>
                  )}}
            </Formik>

            </ScrollView>

        </SafeAreaView>
    );

};
