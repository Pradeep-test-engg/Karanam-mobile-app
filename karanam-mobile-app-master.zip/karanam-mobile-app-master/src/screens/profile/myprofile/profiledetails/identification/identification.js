import React from 'react';
import { SafeAreaView, ScrollView, View } from 'react-native';
import { Formik } from 'formik';
import StatusBar from '../../../../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../../../../styles/index.js';
import Header from '../../../../../components/header/header';
import navigate from './../../../../../utils/navigate';
import TextInputA from './../../../../../components/textInput/textInputA';
import Dropdown from './../../../../../components/dropdown/dropdown';
import DatePick from './../../../../../components/datepicker/datepicker';
import Button from '../../../../../components/button/button';
import TextComp from './../../../../../components/text/text';
import schema from './../../../../../utils/validationSchema';

export default ({ data, onSubmit, status: { loading, error } }) => {

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Id details"}
                    onLeftPress={()=>{navigate({isBack:true})}}
                    />

                <Formik
                    initialValues={data}
                    enableReinitialize={true}
                    onSubmit={onSubmit}
                    validationSchema={schema.id_details}
                >
                {({ handleChange, 
                    handleBlur, 
                    handleSubmit, 
                    setFieldValue,
                    values, 
                    errors,
                    touched,
                    isValid,
                    ...props
                    }) => {
                        console.log("values.has_work_permit",values.has_work_permit);
                    return(
                    <>
                        <View style={{flex:1,marginHorizontal:20}}>

                            <View style={{marginVertical:20,alignItems:"flex-start",justifyContent:"center"}}>
                                <TextComp value={"Id details"} style={{fontSize:size.xxbig}}/>
                                <TextComp value={"Edit id details"} style={{fontSize:size.small,marginTop:6}}/>
                            </View>

                            <TextInputA 
                                placeholder="Adhar number" 
                                name="aadhar" 
                                keyboardType="number-pad" 
                                value={values.aadhar} 
                                onChangeText={handleChange("aadhar")}
                                onBlur={handleBlur("aadhar")}
                                isError={touched && touched.aadhar && errors.aadhar}
                            />

                            <TextInputA 
                                placeholder="Pan number"  
                                name="pan" 
                                value={values.pan} 
                                onChangeText={handleChange("pan")}
                                onBlur={handleBlur("pan")}
                                isError={touched && touched.pan && errors.pan}
                            />

                            <TextInputA 
                                placeholder="Passport number" 
                                name="passport" 
                                value={values.passport} 
                                onChangeText={handleChange("passport")}
                                onBlur={handleBlur("passport")}
                                isError={touched && touched.passport && errors.passport}
                            />

                            <Dropdown
                                placeholder="Do you have work permit"
                                items={[
                                    {label: 'Yes', value: true },
                                    {label: 'No', value: false },
                                ]}
                                onChangeItem={(value)=>{setFieldValue("has_work_permit",value.value)}}
                                value={values.has_work_permit}
                                label ={ values.has_work_permit.toString() == "true" || "false" ? "Work permit" : false }
                                isError={touched && touched.has_work_permit && errors.has_work_permit}
                            />

                            {
                                values.has_work_permit &&
                                <>
                                    <TextInputA 
                                        placeholder="Work permit country" 
                                        value={values.wpContry} 
                                        onChangeText={handleChange("wpContry")}
                                        onBlur={handleBlur("wpContry")}
                                        isError={touched && touched.wpContry && errors.wpContry}
                                    />

                                    <TextInputA 
                                        placeholder="Work permit number" 
                                        value={values.wpNumber} 
                                        onChangeText={handleChange("wpNumber")}
                                        onBlur={handleBlur("wpNumber")}
                                        isError={touched && touched.wpNumber && errors.wpNumber}
                                    />

                                    <DatePick
                                        handleChange={(name,date)=>{ setFieldValue(name,date)}}
                                        name={"startDate"}
                                        value={values.startDate}
                                        label={"Start Date"}
                                        placeHolder={"Select start date"}
                                    />

                                    <DatePick
                                        handleChange={(name,date)=>{ setFieldValue(name,date)}}
                                        name={"endDate"}
                                        value={values.endDate}
                                        label={"End Date"}
                                        placeHolder={"Select end date"}
                                    />

                                </>
                            }

                        </View>

                        <View style={{marginHorizontal:20,marginVertical:30,backgroundColor:"blue",borderRadius:6}}>
                            <Button
                                value={"Update"}
                                onPress={()=>{handleSubmit()}}
                                buttonStyle={{paddingVertical:10}}
                                textStyle={{color:color.white}}
                                loading={loading}
                                disabled={!isValid}
                            />
                        </View>
                    </>
                )}}
            </Formik>

            </ScrollView>

        </SafeAreaView>
    );

};
