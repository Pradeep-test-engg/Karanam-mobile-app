import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import IdDetailsPS from './identification';
import authSelector from '../../../../../store/auth/selector';
import authThunk from '../../../../../store/auth/thunk';

const BasicInfo = () => {

    const id_details = useSelector(authSelector.IdDetails);

    const [ status, setStatus ] = useState({
        loading:false,
        error:null,
    });

    const dispatch = useDispatch();

    const onSubmit = (value) =>{
        const data = {id_details:value};
        (JSON.stringify(id_details) !== JSON.stringify(value)) && dispatch(authThunk.updateProfile({
                data:data,
                handler:setStatus,
                type:"id_details",
            }));
    };

    return (
        <IdDetailsPS data={id_details} status={status} onSubmit={onSubmit} />
    );

};

export default BasicInfo;