import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, TouchableOpacity, Image } from 'react-native';
import StatusBar from '../../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../../styles/index.js';
import Header from '../../../components/header/header';
import TextComp from '../../../components/text/text';
import { FlatList } from 'react-native-gesture-handler';
import { connect } from 'react-redux';
import authSlice from '../../../store/auth/slice';
import { profile_stack } from './../../../navigation/navigator';
import ProfileDetails from './profiledetails/index';

const MyProfile = (props) => {

    const [ show, setShow ] = useState(false);

    // return <ProfileDetails/>
    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Account"}
                    onLeftPress={()=>{props.navigation.goBack()}}
                />

                <View style={{flex:1}}>

                    <View style={{alignItems:"center",justifyContent:"center",marginTop:30}}>
                        <Icon name="user-circle" type="FontAwesome" style={{fontSize:120,color:color.xblue}} />
                    </View>

                    <View style={{marginTop:20}}>
                        <TextComp value={"Nandeesh gowda"} style={{textAlign:"center",fontSize:size.xxxbig}}/>
                        <TextComp value={"nandeesh@gmail.com"} style={{textAlign:"center",fontSize:size.big,marginTop:6}}/>
                    </View>

                    <View style={{marginHorizontal:10,marginTop:20}}>
                        <TouchableOpacity onPress={()=>{props.navigation.navigate(profile_stack.profile_detail)}} style={{backgroundColor:color.xxgray,marginHorizontal:14,marginVertical:6,borderRadius:6,flexDirection:"row",alignItems:"center",justifyContent:"space-between"}}>
                            <TextComp value={"Account details"} style={{textAlign:"left",fontSize:size.big,paddingVertical:12,marginLeft:10}}/>
                            <Icon name="chevron-right" type="MaterialIcons" style={{fontSize:size.xxxbig,right:10}}  />
                        </TouchableOpacity>
                        {/* <TouchableOpacity style={{backgroundColor:color.xxgray,marginHorizontal:14,marginVertical:6,borderRadius:6,flexDirection:"row",alignItems:"center",justifyContent:"space-between"}}>
                            <TextComp value={"Id details"} style={{textAlign:"left",fontSize:size.big,paddingVertical:12,marginLeft:10}}/>
                            <Icon name="chevron-right" type="MaterialIcons" style={{fontSize:size.xxxbig,right:10}}  />
                        </TouchableOpacity>
                        <TouchableOpacity style={{backgroundColor:color.xxgray,marginHorizontal:14,marginVertical:6,borderRadius:6,flexDirection:"row",alignItems:"center",justifyContent:"space-between"}}>
                            <TextComp value={"Education details"} style={{textAlign:"left",fontSize:size.big,paddingVertical:12,marginLeft:10}}/>
                            <Icon name="chevron-right" type="MaterialIcons" style={{fontSize:size.xxxbig,right:10}}  />
                        </TouchableOpacity>
                        <TouchableOpacity style={{backgroundColor:color.xxgray,marginHorizontal:14,marginVertical:6,borderRadius:6,flexDirection:"row",alignItems:"center",justifyContent:"space-between"}}>
                            <TextComp value={"Experience details"} style={{textAlign:"left",fontSize:size.big,paddingVertical:12,marginLeft:10}}/>
                            <Icon name="chevron-right" type="MaterialIcons" style={{fontSize:size.xxxbig,right:10}}  />
                        </TouchableOpacity> */}
                        <TouchableOpacity style={{backgroundColor:color.xxgray,marginHorizontal:14,marginVertical:6,borderRadius:6,flexDirection:"row",alignItems:"center",justifyContent:"space-between"}}
                            onPress={()=>{props.logout()}}>
                            <TextComp value={"Log out"} style={{textAlign:"left",fontSize:size.big,paddingVertical:12,marginLeft:10}}/>
                        </TouchableOpacity> 
                    </View>

                </View>
            </ScrollView>

        </SafeAreaView>
    );

};

const mapDispatchToProps = (dispatch) =>{

    return{
      logout:()=>{dispatch(authSlice.actions.logout())}
    }
  
  }
  
export default connect(null,mapDispatchToProps)(MyProfile);