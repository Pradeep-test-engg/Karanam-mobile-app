import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, TouchableOpacity, Image } from 'react-native';
import StatusBar from '../../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../../styles/index.js';
import Header from '../../../components/header/header';
import TextComp from '../../../components/text/text';
import { FlatList } from 'react-native-gesture-handler';

const MyTest = (props) => {

    const [ show, setShow ] = useState(false);

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"My Test"}
                    onLeftPress={()=>{props.navigation.goBack()}}
                />

                <View style={{flex:1}}>

                    <View style={{marginHorizontal:16,marginTop:16}}>
                        <TextComp value={"All Tests"} style={{textAlign:"left",fontFamily:font.bold,fontSize:size.xxbig}}/>
                    </View>

                    <View style={{marginHorizontal:10,marginTop:16}}>

                        <FlatList
                            data={data}
                            renderItem={renderItem}
                        />

                    </View>

                </View>
            </ScrollView>

        </SafeAreaView>
    );

};

export default MyTest;

const renderItem = ({item,key}) =>{

    return(
        <View key={key} style={{backgroundColor:color.xxgray,marginBottom:12,padding:10,borderRadius:6}}>
            <View style={{flexDirection:"row"}}>

                <View style={{flex:1}}>
                    
                    <View>
                        <TextComp value={item.title} style={{fontSize:size.small,fontFamily:font.bold}}/>
                    </View>

                    <View>
                        <TextComp value={`${item.complete} / 100`} style={{color:color.xgray,fontSize:size.xsmall,marginTop:4}}/>
                    </View>

                </View>

            </View>
        </View>
    )
}

let image = "https://cdn6.f-cdn.com/contestentries/1122631/25928748/59a930ffbbe4c_thumb900.jpg";

const data = [

    {
        image:"https://img-a.udemycdn.com/course/240x135/1726420_7370.jpg?Rp6Kb7cfdz-RkhlL3L0e-ES9g05lSYB1k3eVs5VOmU0OZ5mEFPKJLgwZtQeE6OGLucgJdMFQpftsKCyZXJXurSbwV38ZnbxjxXH16TZ4NwrQhDaplN3Q6NpcMmS04Q",
        title:"RxJs Test",
        author:"Andrie",
        complete:70,
    },
    {
        image:"https://img-a.udemycdn.com/course/240x135/947098_02ec.jpg?AghIl6VOjBC8pS6c0IZgFm90XHhR7diuUVoqT0YpQL70kzGLbNOj4Wr0AOSooDMEA4Fn4mH_2gNEaTvjGOlAypyn2Prd-L9cSuRiPQM6nEOh08FUTOcM0Fmgw_AS",
        title:"TypeScript Test",
        author:"Brad shiff",
        complete:30,
    },
    {
        image:"https://img-a.udemycdn.com/course/240x135/2685124_37c5_2.jpg?BTW3j3LYlgstLAdW8Lic9Mohm088eoO8zXeKovnAXe5HT7AiDVmkna862rD8NxmImIYNXQ5_xLupyFd-XH7Ex3qgdKPtgZxBl9pdP8VEbFBG5GozrdT49lA9akeqROt8",
        title:"Angular Test",
        author:"Stephen grider",
        complete:100,
    },
    {
        image:"https://img-a.udemycdn.com/course/240x135/2887266_c696_5.jpg?ceHty_t-h4BIVF14RmgoGqnl6Q6BonakzrMwowzjX2fKPZSfNchsAVFPgKtYmhdJkr44pXstlxYNZB0RNLE4TA2v0HMe8BgxCB1ealRnmJav1AVVUVssTe-VMb3QWJUv",
        title:"Microservices Test",
        author:"Josh portilla",
        complete:70,
    },
    {
        image:"https://cdn6.f-cdn.com/contestentries/1122631/25928748/59a930ffbbe4c_thumb900.jpg",
        title:"JavaScript Test",
        author:"Colt steele",
        complete:10,
    }

]