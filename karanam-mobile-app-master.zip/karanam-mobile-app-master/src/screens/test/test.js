import React from 'react';
import { SafeAreaView, ScrollView, View, TouchableOpacity, Image, Text } from 'react-native';
import StatusBar from '../../components/statusbar/statusbar';
import { color, font, size, Icon } from '../../styles/index.js';
import Header from '../../components/header/header';
import TextComp from '../../components/text/text';
import Button from '../../components/button/button';
import { FlatList } from 'react-native-gesture-handler';

const Test = (props) => {

    return (
        <SafeAreaView style={{flex:1,backgroundColor:color.white}}>    

            <StatusBar />

            <ScrollView style={{flex:1}} contentContainerStyle={{flexGrow:1,backgroundColor:color.white}}>

                <Header
                    textCenter={"Javascript test"}
                    onLeftPress={()=>{props.navigation.goBack()}}
                    isRight={false}
                />

                <View style={{flex:1,flexDirection:"row"}}>

                    <View style={{alignItems:"flex-start",flex:1,justifyContent:"center",marginLeft:20}}>
                        <TextComp value={"Question 1/30"} style={{fontSize:size.xbig,fontFamily:font.bold}}/>
                    </View>

                    <View style={{alignItems:"flex-start",justifyContent:"center",marginRight:20}}>
                        <TextComp value={"Time left : 20:00"} style={{fontSize:size.medium,fontFamily:font.bold}}/>
                    </View>

                </View>

                <View style={{backgroundColor:"white",flex:2}}>

                    <View style={{flex:0.6}}>
                        <TextComp value={"How to write an IF statement for executing some code if i is NOT equal to 5?"} style={{fontSize:size.big,fontFamily:font.bold}}/>
                    </View>

                    <View style={{flex:1}}>

                        <TouchableOpacity style={{backgroundColor:color.xxgray,marginHorizontal:10,marginVertical:4,borderRadius:14,flexDirection:"row",alignItems:"center",justifyContent:"space-between",borderWidth:2,borderColor:color.xgray}}>
                            <TextComp value={"if (i == 5 )"} style={{paddingVertical:10,marginHorizontal:20}} />
                        </TouchableOpacity>

                        <TouchableOpacity style={{backgroundColor:color.xxgray,marginHorizontal:10,marginVertical:4,borderRadius:14,flexDirection:"row",alignItems:"center",justifyContent:"space-between",borderWidth:2,borderColor:color.xblue}}>
                            <TextComp value={"if (i != 5 )"} style={{paddingVertical:10,marginHorizontal:20}} />
                            <Icon
                                name="check-circle-outline" 
                                type="MaterialIcons" 
                                size={size.xxbig} 
                                color={color.white} 
                                style={{right:10,backgroundColor:color.xblue,borderRadius:100}} 
                            />
                        </TouchableOpacity>

                        <TouchableOpacity style={{backgroundColor:color.xxgray,marginHorizontal:10,marginVertical:4,borderRadius:14,flexDirection:"row",alignItems:"center",justifyContent:"space-between",borderWidth:2,borderColor:color.xgray}}>
                            <TextComp value={"if (i > 5 )"} style={{paddingVertical:10,marginHorizontal:20}} />
                        </TouchableOpacity>

                        
                        <TouchableOpacity style={{backgroundColor:color.xxgray,marginHorizontal:10,marginVertical:4,borderRadius:14,flexDirection:"row",alignItems:"center",justifyContent:"space-between",borderWidth:2,borderColor:color.xgray}}>
                            <TextComp value={"if (i < 5 )"} style={{paddingVertical:10,marginHorizontal:20}} />
                        </TouchableOpacity>

                    </View>

                </View>

                <View style={{flex:1}}>

                <View style={{flex:1,flexDirection:"row",alignItems:"center",justifyContent:"space-around",zIndex:-10}}>

                <Button
                    value={"Previous question"}
                    buttonStyle={{backgroundColor:color.white}}
                    textStyle={{color:color.xgray}}
                    />

                <Button 
                    value={"Next question"}
                    />

                </View>

            </View>

            </ScrollView>
        </SafeAreaView>
    );

};

export default Test;