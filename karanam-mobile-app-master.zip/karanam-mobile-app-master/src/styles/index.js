import color from './color';
import font from './font';
import Icon from './icon';
import size from './size';

export {
    font,
    color,
    Icon,
    size,
};
    