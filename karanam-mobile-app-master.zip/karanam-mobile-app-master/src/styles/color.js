const color = {
    transparent:"#ffffff00",
    
    white:"#ffffff",
    
    black:"#000000",

    orange:"orange",

    red:"red",

    xblue:"#1877f2",

    xgray:"#999999",
    xxgray:"#e8e8e8",
}

export default color;