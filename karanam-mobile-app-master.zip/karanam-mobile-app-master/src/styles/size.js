const size = {
    xsmall:12,
    small:14,
    medium:16,
    big:18,
    xbig:22,
    xxbig:24,
    xxxbig:28,
    xxxxbig:34,
}

export default size;