const font= {
    bold:"QuattrocentoSans-Bold",
    regular:"QuattrocentoSans-Regular",
}

export default font;