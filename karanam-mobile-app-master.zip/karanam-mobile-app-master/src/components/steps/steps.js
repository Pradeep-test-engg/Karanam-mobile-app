import React from 'react';
import StepIndicator from 'react-native-step-indicator';
import { color, font, size } from '../../styles/index.js';

const Step = ({currentPosition=0, labels, stepCount=5}) =>{

    return(
        <StepIndicator
            customStyles={customStyle}
            currentPosition={currentPosition}
            labels={labels}
            stepCount={stepCount}
        />
    )

}

export default Step;


const customStyle = {
    stepIndicatorSize: size.xxxbig,
    currentStepIndicatorSize:size.xxxbig,
    separatorStrokeWidth: 1.5,
    currentStepStrokeWidth: 2,
    stepStrokeCurrentColor:color.xblue,
    stepStrokeWidth: 2,
    stepStrokeFinishedColor: color.white,
    stepStrokeUnFinishedColor: color.xxgray,
    separatorFinishedColor:color.xblue,
    separatorUnFinishedColor: color.xxgray,
    stepIndicatorFinishedColor:color.xblue,
    stepIndicatorUnFinishedColor: color.white,
    stepIndicatorCurrentColor: color.white,
    stepIndicatorLabelFontSize: size.small,
    currentStepIndicatorLabelFontSize: size.small,
    stepIndicatorLabelCurrentColor:color.xblue,
    stepIndicatorLabelFinishedColor: color.white,
    stepIndicatorLabelUnFinishedColor: color.xgray,
    labelColor: color.xgray,
    labelSize: size.xsmall,
    currentStepLabelColor: color.xblue,
    labelFontFamily:font.regular
  }