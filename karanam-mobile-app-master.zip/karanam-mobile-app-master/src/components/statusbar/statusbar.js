import React from 'react';
import { StatusBar as StatusBars } from 'react-native';
import { color} from '../../styles/index.js';

const StatusBar = ({ barStyle="dark-content", backgroundColor=color.white }) =>{

    return(
      <StatusBars barStyle={barStyle} backgroundColor={backgroundColor} />
    )

}

export default StatusBar;