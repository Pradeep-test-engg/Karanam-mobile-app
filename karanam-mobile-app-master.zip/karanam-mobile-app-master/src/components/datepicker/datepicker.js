import React from 'react';
import DatePicker from 'react-native-datepicker';
import { Text, View, TextInput } from 'react-native';
import { color, font, size, Icon } from '../../styles/index.js';
import TextComp from '../text/text';

const DatePick = ({ name, value, label, handleChange, placeHolder, maxDate, minDate }) =>{

    return(
      <View style={{marginVertical:8,borderRadius:10}}>
        {
                value ? <TextComp value={label} style={{position:"absolute",top:-10,left:14,color:"gray",zIndex:100}}/> : null
        }
        <DatePicker
          style={{width:"100%"}}
          date={value}
          mode="date"
          placeholder={placeHolder}
          format="YYYY-MM-DD"
          maxDate={maxDate}
          minDate={minDate}
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"
          customStyles={{
            dateInput:{
              borderRadius:4,
              backgroundColor:color.xxgray,
              borderWidth:0,
            },
            dateText:{
              fontFamily:font.regular,
              fontSize:size.medium
            },
            datePicker:{
              borderRadius:4
            },
            placeholderText:{
              fontFamily:font.regular,
              fontSize:size.medium,
              color:color.xgray
            }
          }}
          showIcon={false}
          onDateChange={(date) => {handleChange(name,date)}}
        />
      </View>
      )
  }

export default DatePick;