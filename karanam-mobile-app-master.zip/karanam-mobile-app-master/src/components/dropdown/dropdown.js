import React from 'react';
import DropDownPicker from 'react-native-dropdown-picker';
import { Text, View, TextInput } from 'react-native';
import RNPickerSelect from 'react-native-picker-select';
import { color, font, size, Icon } from '../../styles/index.js';
import TextComp from '../text/text';

const Dropdown = ({ placeholder, items, onChangeItem, value, isError }) => {

    return(
        <View style={{marginVertical:8}}>
            {
                value ? <TextComp value={placeholder} style={{position:"absolute",top:-10,left:14,color:"gray",zIndex:100}}/> : null
            }
            <RNPickerSelect
                onValueChange={(value)=>onChangeItem(value)}
                value={value}
                placeholder={{
                    label: placeholder,
                    value: value,
                    color: color.black,
                }}
                items={items}
            />
            {
                isError ?
                <TextComp value={isError} style={{color:color.red}} />
                : null
            }
        </View>
    )
}

export default Dropdown;