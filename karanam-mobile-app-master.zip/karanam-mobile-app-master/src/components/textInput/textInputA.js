import React from 'react';
import { Text, View, TextInput } from 'react-native';
import { color, font, size, Icon } from '../../styles/index.js';
import TextComp from '../text/text';

const TextInputA = ({ placeholder, isError=null, editable, onBlur, value, keyboardType, onChangeText, multiline=false, numberOfLines=2 }) => {

    return(
        <>
            <View style={{backgroundColor:color.xxgray,marginVertical:8,borderRadius:6,flexDirection:"row",alignItems:"center"}}>

                {
                    value ? <TextComp value={placeholder} style={{position:"absolute",top:-10,left:14,color:"gray"}}/> : null
                }

                <TextInput
                    onChangeText={(value)=>onChangeText(value)}
                    onBlur={onBlur}
                    placeholder={placeholder}
                    value={value}
                    editable={editable}
                    keyboardType={keyboardType}
                    style={{paddingHorizontal:12,flex:1,fontSize:size.medium,fontFamily:font.regular,paddingVertical:8,textAlignVertical:"top"}}
                    multiline={multiline}
                    numberOfLines={multiline ? numberOfLines : 1}
                />

                {
                    value && !isError ?
                        <Icon
                            name="check-circle-outline" 
                            type="MaterialIcons" 
                            size={size.xxbig} 
                            color={color.xblue} 
                            style={{right:10}} 
                        />
                    :   null
                }

            </View>
            {
                isError ?
                <TextComp value={isError} style={{color:color.red}} />
                : null
            }
        </>
    )
}

export default TextInputA;