import React from 'react';
import { ActivityIndicator } from 'react-native';
import color from './../../styles/color';

export default () => <ActivityIndicator animating={true} color={color.xblue} size={35} />;
