import React from 'react';
import { Text } from 'react-native';
import { font, size } from '../../styles/index.js';

const TextComp = ({ value, style, numberOfLines }) => {

    return(
        <Text
            style={[{fontFamily:font.regular,fontSize:size.medium,textAlign:"center"},style]}
            numberOfLines={numberOfLines}
            >
            {value}
        </Text>
    )
}

export default TextComp;