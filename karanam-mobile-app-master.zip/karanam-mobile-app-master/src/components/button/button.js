import React from 'react';
import { TouchableOpacity, ActivityIndicator } from 'react-native';
import { color, font, size } from '../../styles/index.js';
import TextComp from '../text/text';

const Button= ({ value, onPress, buttonStyle, textStyle, loading, disabled=false }) => {

    return(
        <TouchableOpacity 
            style={[{backgroundColor:color.xblue,borderRadius:6,overflow:"hidden"},buttonStyle]}
            onPress={onPress}
            disabled={disabled}
            >
            {
                loading ?
                <ActivityIndicator 
                    animating={loading} 
                    color={color.white} 
                />
                :
                <TextComp
                    style={[{textAlign:"center",color:color.white,fontFamily:font.bold,fontSize:size.medium},textStyle]}
                    value={value}
                />
            }
        </TouchableOpacity>
    )
}

export default Button;