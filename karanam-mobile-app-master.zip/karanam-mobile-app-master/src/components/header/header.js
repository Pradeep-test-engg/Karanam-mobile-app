import React from 'react';
import { View, Text, SafeAreaView, TouchableOpacity, GestureResponderEvent } from 'react-native';
import { Icon, color, font, size } from '../../styles/index.js';

const leftIconProp = {
    name:"arrow-back-ios",
    type:"MaterialIcons",
    size:size.big,
    color:color.black,
}

const rightIconProp = {
    name:"dots-three-vertical",
    type:"Entypo",
    size:size.big,
    color:color.black,
}

const Header = ({ textCenter, isRight=true, isLeft=true, onLeftPress, onRightPress, leftIcon=leftIconProp, rightIcon=rightIconProp }) => {

    return(
        <SafeAreaView>

            <View style={{flexDirection:"row",display:"flex",height:50,flex:1}}>

                <TouchableOpacity style={{flex:1,alignItems:"flex-start",justifyContent:"center",left:12}} onPress={onLeftPress}>
                    {
                        isLeft ?
                        <Icon name={leftIcon.name} size={leftIcon.size} color={leftIcon.color} type={leftIcon.type} />
                        : null
                    }
                </TouchableOpacity>

                <View style={{flex:2,alignItems:"center",justifyContent:"center"}}>
                    <Text style={{fontSize:size.big,textAlign:"center",fontFamily:font.bold}}>{textCenter}</Text>
                </View>

                <TouchableOpacity style={{flex:1,alignItems:"flex-end",justifyContent:"center",right:12}} onPress={onRightPress}>
                    {
                        isRight ?
                        <Icon name={rightIcon.name} size={rightIcon.size} color={rightIcon.color} type={rightIcon.type} />
                        : null
                    }
                </TouchableOpacity>

            </View>

      </SafeAreaView>
    )

}

export default Header;