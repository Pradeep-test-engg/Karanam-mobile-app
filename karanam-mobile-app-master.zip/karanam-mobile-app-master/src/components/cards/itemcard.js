import React from 'react';
import { TouchableOpacity, StyleSheet } from 'react-native';
import PropTypes from 'prop-types';
import { color, font, size, Icon } from '../../styles/index.js';
import TextComp from './../text/text';

const ItemCard = (props) => {

    const {
        text,
        textStyle,
        itemStyle,
        onPress,
    } = props; 

    return (
        <TouchableOpacity 
            style={[styles.itemWraper, {...itemStyle}]}
            onPress={onPress}
            >
            <TextComp
                value={text} 
                style={[styles.text, {...textStyle}]}
                />
            <Icon
                name="chevron-right" 
                type="MaterialIcons" 
                style={styles.icon}
                />
        </TouchableOpacity>
    );

};

export default ItemCard;

const styles = StyleSheet.create({
    itemWraper:{
        flexDirection:"row",
        alignItems:"center",
        justifyContent:"space-between",
        backgroundColor:color.xxgray,
        borderRadius:6,
    },
    text:{
        textAlign:"left",
        fontSize:size.big,
        marginLeft:10,
    },
    icon:{
        fontSize:size.xxxbig,
        right:10,
    }
})

ItemCard.propTypes = {
    text: PropTypes.string,
    itemStyle: PropTypes.object,
    onPress: PropTypes.func
  };