import React, { useState, useEffect, useRef } from "react";
import { StyleSheet, Text, View, StatusBar, TouchableOpacity } from "react-native";
import Video from "react-native-video";
import MediaControls, { PLAYER_STATES } from 'react-native-media-controls';
import Orientation from 'react-native-orientation';
import { color, font, size, Icon } from '../../styles/index.js';

const VideoPlay = (props) => {
  const videoPlayer = useRef(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [orientation, setOrientation] = useState("PORTRAIT");
  const [duration, setDuration] = useState(0);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [paused, setPaused] = useState(false);
  const [playerState, setPlayerState] = useState(PLAYER_STATES.PLAYING);

  const noop = () => {
        
    if(orientation == "LANDSCAPE"){
      Orientation.lockToPortrait();
      setOrientation("PORTRAIT");
    }
    else if(orientation == "PORTRAIT"){
      Orientation.lockToLandscape();
      setOrientation("LANDSCAPE");
    }
  };

  const onSeek = (seek) => {
    videoPlayer?.current.seek(seek);
  };

  // useEffect(()=>{

  //   props.navigation.addListener('beforeRemove', (e) => {
  //       setOrientation((prevState)=>{
  //           if(prevState == "LANDSCAPE"){
  //               Orientation.lockToPortrait();
  //               e.preventDefault();
  //               return "PORTRAIT";
  //           }
  //           return prevState;
  //       })
  //     });
   
  //   return ()=>{
  //       Orientation.lockToPortrait();
  //   }
  // },[]);


  const onPaused = (playerState) => {
    setPaused(!paused);
    setPlayerState(playerState);
  };

  const onReplay = () => {
    setPlayerState(PLAYER_STATES.PLAYING);
    videoPlayer?.current.seek(0);
  };

  const onProgress = (data) => {
    console.log(data);    
    if (!isLoading) {
      setCurrentTime(data.currentTime);
    }
    // if(parseInt(calc_progress(data)) >= 90){
    //     props.handleProgressUpdate();
    // }
  };

  const onLoad = (data) => {
    setDuration(data.duration);
    setIsLoading(false);
  };

  const onLoadStart = () => setIsLoading(true);

  const onEnd = () => {
    
  };

  const onSeeking = (currentTime) => setCurrentTime(currentTime);

  const calc_progress = ({ currentTime, seekableDuration }) => (currentTime / seekableDuration) * 100;

  const style = (orientation != "LANDSCAPE") ? { height:"40%" } : { flex:1 };

  return (
      <View style={{flex:1}}>
    <View style={[styles.container], { ...style }}>
      { orientation == "LANDSCAPE" &&  <StatusBar hidden /> }
      <Video
        onEnd={onEnd}
        onLoad={onLoad}
        onLoadStart={onLoadStart}
        onProgress={onProgress}
        onBuffer={onLoadStart}
        paused={paused}
        onError={(e)=>{console.log("errorrrrrrrrrr",e);}}
        ref={(ref) => (videoPlayer.current = ref)}
        resizeMode="contain"
        source={{
          uri: 'https://163vod-adaptive.akamaized.net/exp=1610376482~acl=%2F903ab233-7b3f-4473-9653-ed75056f8182%2F%2A~hmac=442321c8c66919926972a7c95a5a44b3308309eb50db1f03fc2c1e1c33608210/903ab233-7b3f-4473-9653-ed75056f8182/sep/video/c26c7cef,92c988e1,bac7e281/master.m3u8'
        }}
        repeat
        style={styles.mediaPlayer}
        volume={null}
      />
      <MediaControls
        isFullScreen={isFullScreen}
        duration={duration}
        isLoading={isLoading}
        mainColor={color.orange}
        onFullScreen={noop}
        onPaused={onPaused}
        onReplay={onReplay}
        onSeek={onSeek}
        onSeeking={onSeeking}
        playerState={playerState}
        progress={currentTime}
      >
        <MediaControls.Toolbar>
        { 
          orientation == "LANDSCAPE" &&  
          <TouchableOpacity style={styles.toolbar} onPress={noop}>
            <Text>Go Back</Text>
          </TouchableOpacity> 
        }
        </MediaControls.Toolbar>
      </MediaControls>
    </View>
    { orientation == "PORTRAIT" && props.children }
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    // height:300,
    // flex:1,
  },
  toolbar: {
    marginTop: 30,
    backgroundColor: "white",
    padding: 10,
    borderRadius: 5,
  },
  mediaPlayer: {
    position: "absolute",
    flex:1,
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    backgroundColor: "black",
  },
});

export default VideoPlay;