import { GoogleSignin } from '@react-native-community/google-signin';

GoogleSignin.configure({
    webClientId: '775592742356-8rh5vj6tbe26s0g2815ah3gj9dafbivd.apps.googleusercontent.com',
  });

export default GoogleSignin;