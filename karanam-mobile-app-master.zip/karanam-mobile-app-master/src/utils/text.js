const text = {

    signUp:"Sign up",
    loginOtp:"Login with OTP",
    forgotPswd:"Forgot password",
    
}

export default text;