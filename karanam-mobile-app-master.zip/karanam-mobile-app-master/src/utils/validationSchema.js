import * as Yup from 'yup';

const yup = Yup.object();

const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

const passwordRegExp = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;

const basic_info = yup.shape({
        firstname: Yup.string().max(20).required('First name is required'),
        lastname: Yup.string().max(20).required('Last name is required'),
        address: Yup.string().max(100).required('Address is required'),
    });

const id_details = yup.shape({
    aadhar: Yup.string().max(12).min(12).required('aadhar is required'),
    pan: Yup.string().max(10).min(10).required('pan is required'),
    passport: Yup.string().max(10).required('passport is required'),
    has_work_permit: Yup.string().required('has work permit is required'),
    wpContry: Yup.string().max(100).required('work permit country is required'),
    wpNumber: Yup.string().max(100).required('work permit number is required'),
    startDate: Yup.string().required('start date is required'),
    endDate: Yup.string().required('end date is required'),
});

const password = yup.shape({
    password: Yup.string().required('Please Enter your old password'),
    new_password: Yup.string().required('Please Enter new password').matches(passwordRegExp,"Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and one special case Character"),
    confirm_password: Yup.string().required('Please confirm new password').oneOf([Yup.ref('new_password'), null], 'New Password must match'),
});

export default {
    basic_info:basic_info,
    id_details:id_details,
    password:password,
}
