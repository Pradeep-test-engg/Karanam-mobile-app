import { validate } from 'validate.js';

const validator = {

    isFilled:(name,value,length)=>{

        const error = validate.single(value, {presence: {allowEmpty: false}, length: length ? {minimum: length} : null});
        if(error){
            return `${name.split('_').join(' ')} ${error}`;
        }
        return false;
    },

    isEmail:(name,value)=>{

        const error = validate.single(value, {presence: {allowEmpty: false},email: true});
        if(error){
            return `${name.split('_').join(' ')} ${error}`;
        }
        return false;
    },

    isNumber:(name,value,length)=>{

        const error = validate.single(value, { presence: {allowEmpty: false}, length: length ? {is: length} : null});
        if(error){
            return `Please enter ${length} digit number`;
        }
        return false;
    },

    isObjFilled:(name,value)=>{

        const valArray = Object.getOwnPropertyNames(value);

        let error = false;

        valArray.map((val) => {

            error = validate.single(value[val], {presence: {allowEmpty: false}})
            if(error){
                // error = `${name.split('_').join(' ')} ${error}`;
                error = "Please enter all the fields";
            }
        })

        return error;
    }

}

export default validator;